import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;


public class PurchaseGoods implements ActionListener {
	static JTextField purchaseDate1,add1,email1,cp,d,da,td1,tp1,ta1,aa,pp,cpr,email3,pp2,supplierName3,supplierId;
	static JTextArea add2;
	static JButton submit,calculate;
	static Choice um1;
	static JButton back;
	static JFrame frame;
	static JLabel purchaseDate,add,phn,email,cperson,discount,discounta,td,tp,ta,apay,note,status;
	//int discount_percent=Integer.parseInt(PurchaseGoods.d.getText());
	 //int discount_amount=0,total_amount=0,tax_percent=0,tax_amount=0;
	public void actionPerformed(ActionEvent ae){
		
		 frame=new JFrame();
		frame.setVisible(true);
		frame.getContentPane().setBackground(Color.white);
		 frame.setLayout(null);
		 frame.setSize(1500,1500);
		 frame.setTitle("Welcome to Inventory Management System");
		 
		  purchaseDate=new JLabel("Purchase Date");
		 purchaseDate.setBounds(70,90,90,60);
		 frame.add(purchaseDate);
		 Calendar now = Calendar.getInstance();
         int month = now.get(Calendar.MONTH);
         int day = now.get(Calendar.DAY_OF_MONTH);
         int year = now.get(Calendar.YEAR);
         
		 purchaseDate1 =new JTextField();
		 purchaseDate1.setBounds(250,100,90,20);
		// purchaseDate1.setText("" + (month + 1) + "/" + day + "/" + year);
		 purchaseDate1.setText("" + year + "-" + (month+1) + "-" + day);
		 frame.add(purchaseDate1);
		 
		 JLabel add=new JLabel("Stock Name");
		 add.setBounds(70,130,150,60);
		 frame.add(add);
		  add1=new JTextField();
		 add1.setBounds(250,140,90,20);
		 frame.add(add1);
		 
		  JLabel phn=new JLabel("Unit of Measurement");
		  phn.setBounds(70,170,120,60);
		  frame.add(phn);
		  um1=new Choice();
			 um1.add("KG");
			 um1.add("MM");
			 um1.add("CM");
			 um1.add("ML");
			 um1.add("Meter");
			 um1.add("Liter");
		  um1.setBounds(250,180,90,20);
		  frame.add(um1);
		  
		  JLabel email=new JLabel("Purchasing Price");
		  email.setBounds(70,210,150,60);
		  frame.add(email);
		 email1 =new JTextField();
		 email1.setEditable(false);
		  email1.setBounds(250,220,80,20);
		  frame.add(email1);
		  
		  JLabel cperson=new JLabel("Quantity");
		  cperson.setBounds(70,250,90,60);
		  frame.add(cperson);
		  cp =new JTextField();
		  cp.setBounds(250,260,20,20);
		  frame.add(cp);
		  
		  JLabel discount=new JLabel("Discount Percentage");
		  discount.setBounds(70,290,150,60);
		  frame.add(discount);
		 d=new JTextField();
		 d.setBounds(250,300,90,20);
		 frame.add(d);
		 
		 
		 
		 JLabel discounta=new JLabel("Discount Amount");
		  discounta.setBounds(70,330,98,60);
		  frame.add(discounta);
		 // discount_amount=(total_amount/100)*discount_percent;
		da=new JTextField();
		//PurchaseGoods.da.setText(""+discount_amount);
		 da.setBounds(250,340,90,20);
		 da.setEditable(false);
		 frame.add(da);
		 
		 JLabel td=new JLabel("Tax Description");
		  td.setBounds(70,370,90,60);//70,370,90,60
		  frame.add(td);
		  td1=new JTextField();
		  td1.setText("GST");
		  td1.setEditable(false);
		 td1.setBounds(250,380,90,20);//250,380,90,20
		 frame.add(td1);
		 
		 JLabel tp=new JLabel("Tax Percent");
		  tp.setBounds(70,410,90,60);//70,410,90,60
		  frame.add(tp);
		   tp1=new JTextField();
		 tp1.setBounds(250,420,90,20);
		 //tax_percent=Integer.parseInt(PurchaseGoods.tp1.getText());
		 frame.add(tp1);
		 
		 JLabel ta=new JLabel("Tax Amount");
		  ta.setBounds(70,450,90,60);
		  frame.add(ta);
		  ta1=new JTextField();
		  ta1.setEditable(false);
		 ta1.setBounds(250,460,90,20);
		// tax_amount=(total_amount/100)*tax_percent;
		// PurchaseGoods.ta1.setText(""+tax_amount);
		 frame.add(ta1);
		 
		 JLabel a=new JLabel("Total Amount");
		  a.setBounds(70,490,90,60);
		  frame.add(a);
		  aa=new JTextField();
		 // total_amount=total_amount-(total_amount/100)*discount_percent+tax_amount;
		 aa.setBounds(250,500,90,20);
		 aa.setEditable(false);
		// PurchaseGoods.aa.setText(""+total_amount);
		 frame.add(aa);
		 
		 JLabel pay=new JLabel("Payment");
		  pay.setBounds(70,530,90,60);//70,530,90,60
		  frame.add(pay);
		   pp=new JTextField();
		pp.setBounds(250,540,90,20);//250,540,90,20
		 frame.add(pp);
		 
		 JLabel supplierid=new  JLabel("Supplier Id");
		 supplierid.setBounds(400,100,100,20);
		 frame.add(supplierid);
		 supplierId =new JTextField();
		 supplierId.setBounds(500,100,90,20);
		 frame.add(supplierId);
		 
		 JLabel supplierName2=new  JLabel("Supplier Name");
		 supplierName2.setBounds(400,140,100,20);
		 frame.add(supplierName2);
		 supplierName3 =new JTextField();
		 supplierName3.setBounds(500,140,90,20);
		 supplierName3.setEditable(false);
		 frame.add(supplierName3);
		 
		 JLabel addd=new  JLabel("Address");
		 addd.setBounds(400,180,100,20);
		 frame.add(addd);
		 add2=new JTextArea();
		 add2.setBounds(500,180,300,20);//500,180,100,20
		 Border border = BorderFactory.createLineBorder(Color.BLACK);
		 //add1.setSize(400, 200);
		 add2.setBorder(border);
		 add2.setEditable(false);
		 frame.add(add2);
		 
		 JLabel phn1=new  JLabel("Phone Number");
		  phn1.setBounds(400,200,120,60);
		  frame.add(phn1);
		   pp2 =new JTextField();
		  pp2.setBounds(500,220,90,20);
		  pp2.setEditable(false);
		  frame.add(pp2);
		  
		 JLabel email2=new  JLabel("Email");
		  email2.setBounds(400,240,90,60);
		  frame.add(email2);
		 email3 =new JTextField();
		  email3.setBounds(500,260,90,20);
		  email3.setEditable(false);
		  frame.add(email3);
		  
		  JLabel cperson1=new  JLabel("Contact Person");
		  cperson1.setBounds(400,280,90,60);
		  frame.add(cperson1);
		 cpr =new JTextField();
		  cpr.setBounds(500,300,90,20);
		  cpr.setEditable(false);
		  frame.add(cpr);
		  
		 
		 Database db=new Database();
		  submit=new JButton("SUBMIT");
		 //submit.setBounds(100,600,80,20);
		  submit.setBounds(250,580,80,30);
		  submit.setBackground(new Color(51,153,225));
			submit.setForeground(Color.white);
		 submit.addActionListener(db);
		 frame.add(submit);
		 
		 back=new JButton("BACK");
		 CLosePage p=new CLosePage();
		  back.setBounds(350,580,80,30);
		  back.setBackground(new Color(51,153,225));
			back.setForeground(Color.white);
		  back.addActionListener(p);
		  frame.add(back);
		  
		  CalculateTax cal=new CalculateTax();
		  calculate=new JButton("CALCULATE");
		  calculate.setBounds(280, 650, 150, 30);
		  calculate.addActionListener(cal);
		  calculate.setBackground(new Color(51,153,225));
			calculate.setForeground(Color.white);
		  frame.add(calculate);

		  note=new JLabel();
		  note.setBounds(450, 650, 300, 20);
		  note.setText("*Note:Calculate and then put payment amount..");
		  frame.add(note);
		  
		  status=new JLabel();
		  status.setBounds(780, 650, 200, 30);
		  frame.add(status);
	}
}
