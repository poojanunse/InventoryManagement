import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class ViewSale extends JFrame implements ActionListener{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
static JButton back;
static JFrame frame;

public void actionPerformed(ActionEvent e) {
	
	Connection con=null;
	frame=new JFrame();
	frame.getContentPane().setBackground(Color.white);
	frame.setVisible(true);
	 frame.setLayout(new GridLayout(2,0));
	 frame.setSize(1500,1500);
	 frame.setTitle("Welcome to Inventory Management System");
	
	
	 
	 
	try{
		int i=0;
		 Class.forName("org.sqlite.JDBC");
		 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
		 con.setAutoCommit(false);
		 System.out.println("SQLite3 Connection Established ...");
		
		 
			 
		 //view saletosupplier
		 if(e.getSource()==Sales.dispaddstockb){
			 
			 String[] columnNames ={"ID","date","stockname","availqty","sellprice","qty","discount_per","discount_amount","tax_desc","tax_percent","tax_amount","total_amount","payment","supplier_id","address","phn","email","contact_person","supplier_name","RemainingBalance"};
			 DefaultTableModel model = new DefaultTableModel();
				model.setColumnIdentifiers(columnNames);
			 JTable table=new JTable();
			 table.setModel(model);		
				table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				table.setFillsViewportHeight(true);
				table.setBackground(Color.white);
				table.getColumnModel().getColumn(1).setPreferredWidth(10);
				table.getColumnModel().getColumn(2).setPreferredWidth(10);
				
				JScrollPane scroll = new JScrollPane(table);
				scroll.setHorizontalScrollBarPolicy(
						JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				scroll.setVerticalScrollBarPolicy(
						JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);	
		
			 String query="select * from saletosupplier" ;
			 Statement statement=con.createStatement();
			 ResultSet result_set=statement.executeQuery(query);
			//ResultSetMetaData metadata=result_set.getMetaData();
			 String id="", date="",stockname="",availqty="",sellprice="",qty="",discount_per="",discount_amount="", tax_desc="";
			 String tax_percent="",tax_amount="",total_amount="",payment="", supplier_id="",address="",phn="",email="";
			 String contact_person="",supplier_name="";
			 
			// JTable jt=new JTable(result_set[i],metadata[i]);  
			 String row[]={"ID","date","stockname","availqty","sellprice","qty","discount_per","discount_amount","tax_desc","tax_percent","tax_amount","total_amount","payment","supplier_id","address","phn","email","contact_person","supplier_name","RemainingBalance"};
			 
				while(result_set.next())
		        {
					id=result_set.getString(1);
					date=result_set.getString(2);
					stockname=result_set.getString(3);	
					availqty=result_set.getString(4);
					sellprice=result_set.getString(5);
					qty=result_set.getString(6);
					discount_per=result_set.getString(7);
					discount_amount=result_set.getString(8);
					tax_desc=result_set.getString(9);
					tax_percent=result_set.getString(10);
					tax_amount=result_set.getString(11);
					total_amount=result_set.getString(12);
					payment=result_set.getString(13);
					supplier_id=result_set.getString(14);
					address=result_set.getString(15);
					phn=result_set.getString(16);
					email=result_set.getString(17);
					contact_person=result_set.getString(18);
					supplier_name=result_set.getString(19);
					String bal=result_set.getString(20);
					model.addRow(new Object[]{id,date,stockname,availqty,sellprice,qty,discount_per,discount_amount,tax_desc,tax_percent,tax_amount,total_amount,payment,supplier_id,address,phn,email,contact_person,supplier_name,bal});
					i++;				
		        }
				if(i <1)
				{
					JOptionPane.showMessageDialog(null, "No Record Found","Error",
							JOptionPane.ERROR_MESSAGE);
				}
				if(i ==1)
				{
				System.out.println(i+" Record Found");
				}
				else
				{
					System.out.println(i+" Records Found");
				}
				 frame.add(scroll);
		 }
	
	
	//view saletocustomer
	if(e.getSource()==Sales.dispviewstockb){
		 String[] columnNames = {"ID","date","stockname","availqty","sellprice","qty","discount_per","discount_amount","tax_desc","tax_percent","tax_amount","total_amount","payment","customer_id","address","phn","email","contact_person","customer_name","RemainingBalance"};
		 DefaultTableModel model = new DefaultTableModel();
			model.setColumnIdentifiers(columnNames);
		 JTable table=new JTable();
		 table.setModel(model);		
			table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			table.setFillsViewportHeight(true);
			table.setBackground(Color.white);
			table.getColumnModel().getColumn(1).setPreferredWidth(10);
			table.getColumnModel().getColumn(2).setPreferredWidth(10);
			
			JScrollPane scroll = new JScrollPane(table);
			scroll.setHorizontalScrollBarPolicy(
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		 String query="select * from saletocustomer" ;
		 Statement statement=con.createStatement();
		 ResultSet result_set=statement.executeQuery(query);
		//ResultSetMetaData metadata=result_set.getMetaData();
		 String id="", date="",stockname="",availqty="",sellprice="",qty="",discount_per="",discount_amount="", tax_desc="";
		 String tax_percent="",tax_amount="",total_amount="",payment="", customer_id="",address="",phn="",email="";
		 String contact_person="",customer_name="";
		
		// JTable jt=new JTable(result_set[i],metadata[i]);  
		 String row[]={"ID","date","stockname","availqty","sellprice","qty","discount_per","discount_amount","tax_desc","tax_percent","tax_amount","total_amount","payment","customer_id","address","phn","email","contact_person","customer_name","RemainingBalance"};
		 
			while(result_set.next())
	        {
				id=result_set.getString(1);
				date=result_set.getString(2);
				stockname=result_set.getString(3);	
				availqty=result_set.getString(4);
				sellprice=result_set.getString(5);
				qty=result_set.getString(6);
				discount_per=result_set.getString(7);
				discount_amount=result_set.getString(8);
				tax_desc=result_set.getString(9);
				tax_percent=result_set.getString(10);
				tax_amount=result_set.getString(11);
				total_amount=result_set.getString(12);
				payment=result_set.getString(13);
				customer_id=result_set.getString(14);
				address=result_set.getString(15);
				email=result_set.getString("email");
				contact_person=result_set.getString("contact_person");
				customer_name=result_set.getString("customer_name");
				phn=result_set.getString("phn");
				String bal=result_set.getString(20);
				model.addRow(new Object[]{id,date,stockname,availqty,sellprice,qty,discount_per,discount_amount,tax_desc,tax_percent,tax_amount,total_amount,payment,customer_id,address,phn,email,contact_person,customer_name,bal});
				i++;				
	        }
			if(i <1)
			{
				JOptionPane.showMessageDialog(null, "No Record Found","Error",
						JOptionPane.ERROR_MESSAGE);
			}
			if(i ==1)
			{
			System.out.println(i+" Record Found");
			}
			else
			{
				System.out.println(i+" Records Found");
			}
			 frame.add(scroll);
	}
	 JPanel panel = new JPanel();        
	    panel.setLayout(null);
	 back=new JButton("BACK");
	 CLosePage p=new CLosePage();
	  back.setBounds(300,100,80,30);
	  back.setBackground(new Color(51,153,225));
		back.setForeground(Color.white);
	  back.addActionListener(p);
	  panel.add(back);
	  frame.add(panel);
	}catch(Exception ee){
		System.out.println(ee);
	}finally{
		try{
			con.close();
		}catch(Exception ee){
			System.out.println(ee);
		}
	}
	
}
}
