import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Sales extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JButton viewstockb,addstockb,back,dispaddstockb,dispviewstockb;
	static JFrame salesFrame;
	public void actionPerformed(ActionEvent ae){
		DesignClass.frame.setVisible(false);
		 salesFrame=new JFrame();
		salesFrame.setVisible(true);
		salesFrame.getContentPane().setBackground(Color.white);
		salesFrame.setSize(1500,1500);
		salesFrame.setFont(new Font("Dialog", Font.PLAIN, 12));
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		salesFrame.setLayout(null);
		salesFrame.setTitle("Sales");

		SaleToSupplier addStock =new SaleToSupplier();
		SaleToCustomer viewStock=new SaleToCustomer();
		
		addstockb=new JButton("SaleToSupplier");
		addstockb.setBounds(30,200,180,30);
		addstockb.addActionListener(addStock);
		addstockb.setBackground(new Color(51,153,225));
		addstockb.setForeground(Color.white);
		salesFrame.add(addstockb);
		
		
		 viewstockb=new JButton("SaleToCustomer");
		viewstockb.setBounds(30,250,180,30);
		viewstockb.addActionListener(viewStock);
		viewstockb.setBackground(new Color(51,153,225));
		viewstockb.setForeground(Color.white);
		salesFrame.add(viewstockb);
		
		ViewSale v=new ViewSale();
		dispaddstockb=new JButton("ViewSaleToSupplier");
		dispaddstockb.setBounds(30,300,180,30);
		dispaddstockb.addActionListener(v);
		dispaddstockb.setBackground(new Color(51,153,225));
		dispaddstockb.setForeground(Color.white);
		salesFrame.add(dispaddstockb);
		
		
		 dispviewstockb=new JButton("ViewSaleToCustomer");
		 dispviewstockb.setBounds(30,350,180,30);
		 dispviewstockb.addActionListener(v);
		 dispviewstockb.setBackground(new Color(51,153,225));
			dispviewstockb.setForeground(Color.white);
		salesFrame.add(dispviewstockb);
		
		
		
		
		CLosePage close=new CLosePage(); 
		back=new JButton("Back");
		back.setBounds(30,400,180,30);
		back.setBackground(new Color(51,153,225));
		back.setForeground(Color.white);
		back.addActionListener(close);
		salesFrame.add(back);
		
		JLabel image=new JLabel(new ImageIcon(this.getClass().getResource("/images/sales.jpg")));
		image.setBounds(230, 100, 800, 500);
		salesFrame.add(image);
		
	}

}
