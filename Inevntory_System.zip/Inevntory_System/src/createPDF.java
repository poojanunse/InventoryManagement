import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;

//import javax.swing.text.Document;






import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class createPDF implements ActionListener {
@Override

public void actionPerformed(ActionEvent e) {
	 Document document = new Document();
     //document.open();
	if(e.getSource()==FinalSupplierPayment.viewPDF){
		try{
	 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("SupplierSalesPayment.pdf"));
	 document.open();
	 document.add(new Paragraph("SUPPLIER SALES PAYMENT"));
	 PdfPTable table=new PdfPTable(2);
	 table.setWidthPercentage(100);
	 table.setSpacingAfter(11f);
	 table.setSpacingBefore(11f);
	 float[] colWidth={1f,1.5f};//,1f,1f,0.5f,0.5f,1f,1f,0.5f,1.5f,0.5f,1.8f,3f,1.8f};//3f,3f,3f,3f,3f,3f,3f,3f,3f,3f};//,2f,2f,2f,2
	 table.setWidths(colWidth);
	
	 PdfPCell c2=new PdfPCell(new Paragraph("Date"));
	 PdfPCell cc2=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 1)+""));
	 PdfPCell c3=new PdfPCell(new Paragraph("StockName"));
	 PdfPCell cc3=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 2)+""));
	 PdfPCell c4=new PdfPCell(new Paragraph("Avail_Qty"));
	 PdfPCell cc4=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 3)+""));
	 PdfPCell c5=new PdfPCell(new Paragraph("SellPrice"));
	 PdfPCell cc5=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 4)+""));
	 PdfPCell c6=new PdfPCell(new Paragraph("Qty"));
	 PdfPCell cc6=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 5)+""));
	 PdfPCell c7=new PdfPCell(new Paragraph("Disc%"));
	 PdfPCell cc7=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 6)+""));
	PdfPCell c8=new PdfPCell(new Paragraph("Disc_Amt"));
	 PdfPCell cc8=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 7)+""));
	 PdfPCell c9=new PdfPCell(new Paragraph("Tax_Desc"));
	 PdfPCell cc9=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 8)+""));
	 PdfPCell c10=new PdfPCell(new Paragraph("Tax%"));
	 PdfPCell cc10=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 9)+""));
	 PdfPCell c11=new PdfPCell(new Paragraph("TaxAmount"));
	 PdfPCell cc11=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 10)+""));
	 PdfPCell c12=new PdfPCell(new Paragraph("TotalAmount"));
	 PdfPCell cc12=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 11)+""));
	 PdfPCell c13=new PdfPCell(new Paragraph("PayDone"));
	 PdfPCell cc13=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 12)+""));
	 PdfPCell c16=new PdfPCell(new Paragraph("Phone"));
	 PdfPCell cc16=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 15)+""));
	 PdfPCell c19=new PdfPCell(new Paragraph("SupplierName"));
	 PdfPCell cc19=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 18)+""));
	 PdfPCell c20=new PdfPCell(new Paragraph("RemainingBalance"));
	 PdfPCell cc20=new PdfPCell(new Paragraph(FinalSupplierPayment.model.getValueAt(0, 19)+""));
	
	
	 table.addCell(c2);
	 table.addCell(cc2);
	 table.addCell(c3);
	 table.addCell(cc3);
	 table.addCell(c4);
	 table.addCell(cc4);
	 table.addCell(c5);
	 table.addCell(cc5);
	 table.addCell(c6);
	 table.addCell(cc6);
	 table.addCell(c7);
	 table.addCell(cc7);
	 table.addCell(c8);
	 table.addCell(cc8);
	 table.addCell(c9);
	 table.addCell(cc9);
	 table.addCell(c10);
	 table.addCell(cc10);
	 table.addCell(c11);
	 table.addCell(cc11);
	 table.addCell(c12);
	 table.addCell(cc12);
	 table.addCell(c13);
	 table.addCell(cc13);
	 table.addCell(c16);
	 table.addCell(cc16);
	 table.addCell(c19);
	 table.addCell(cc19);
	table.addCell(c20);
	table.addCell(cc20);
	

	
	 document.add(table);
	 document.close();
	 writer.close();
	 File myFile = new File( "SupplierSalesPayment.pdf");
     Desktop.getDesktop().open(myFile);
	 
		}catch(Exception ee){
			System.out.println(ee);
		}
	}
	
	
	if(e.getSource()==FinalSupplierPurchasePayment.viewPDF){
		try{
	 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("SupplierPurchasePayment.pdf"));
	 document.open();
	 document.add(new Paragraph("SUPPLIER PURCHASE PAYMENT"));
	 PdfPTable table=new PdfPTable(2);
	 table.setWidthPercentage(100);
	 table.setSpacingAfter(11f);
	 table.setSpacingBefore(11f);
	 float[] colWidth={1f,1.5f};//,2f,3f,2f,2f,2f,4f,2f,2f,2f,5f,2f,2f,2f,2f,2f,2f,2f};
	 table.setWidths(colWidth);
	
	
	 PdfPCell c2=new PdfPCell(new Paragraph("PurchaseDate"));
	 PdfPCell cc2=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 1)+""));
	 PdfPCell c3=new PdfPCell(new Paragraph("StockName"));
	 PdfPCell cc3=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 2)+""));
	 PdfPCell c4=new PdfPCell(new Paragraph("Unit Of Measurement"));
	 PdfPCell cc4=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 3)+""));
	 PdfPCell c5=new PdfPCell(new Paragraph("PurchasingPrice"));
	 PdfPCell cc5=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 4)+""));
	 PdfPCell c6=new PdfPCell(new Paragraph("Qty"));
	 PdfPCell cc6=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 5)+""));
	 PdfPCell c7=new PdfPCell(new Paragraph("Discount%"));
	 PdfPCell cc7=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 6)+""));
	 PdfPCell c8=new PdfPCell(new Paragraph("DiscountAmount"));
	 PdfPCell cc8=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 7)+""));
	 PdfPCell c9=new PdfPCell(new Paragraph("Tax_Desc"));
	 PdfPCell cc9=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 8)+""));
	 PdfPCell c10=new PdfPCell(new Paragraph("Tax%"));
	 PdfPCell cc10=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 9)+""));
	 PdfPCell c11=new PdfPCell(new Paragraph("TaxAmount"));
	 PdfPCell cc11=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 10)+""));
	 PdfPCell c12=new PdfPCell(new Paragraph("TotalAmount"));
	 PdfPCell cc12=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 11)+""));
	 PdfPCell c13=new PdfPCell(new Paragraph("PaymentDone"));
	 PdfPCell cc13=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 12)+""));
	 PdfPCell c15=new PdfPCell(new Paragraph("SupplierName"));
	 PdfPCell cc15=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 14)+""));
	 PdfPCell c17=new PdfPCell(new Paragraph("Phone NO."));
	 PdfPCell cc17=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 16)+""));
	 PdfPCell c19=new PdfPCell(new Paragraph("RemainingBalance"));
	 PdfPCell cc19=new PdfPCell(new Paragraph(FinalSupplierPurchasePayment.model.getValueAt(0, 19)+""));
	
	 table.addCell(c2);
	 table.addCell(cc2);
	 table.addCell(c3);
	 table.addCell(cc3);
	 table.addCell(c4);
	 table.addCell(cc4);
	 table.addCell(c5);
	 table.addCell(cc5);
	 table.addCell(c6);
	 table.addCell(cc6);
	 table.addCell(c7);
	 table.addCell(cc7);
	 table.addCell(c8);
	 table.addCell(cc8);
	 table.addCell(c9);
	 table.addCell(cc9);
	 table.addCell(c10);
	 table.addCell(cc10);
	 table.addCell(c11);
	 table.addCell(cc11);
	 table.addCell(c12);
	 table.addCell(cc12);
	 table.addCell(c13);
	 table.addCell(cc13);
	 table.addCell(c15);
	 table.addCell(cc15);
	 table.addCell(c17); 
	 table.addCell(cc17);
	 table.addCell(c19);
		table.addCell(cc19);
		
	  
	
	 document.add(table);
	 document.close();
	 writer.close();
	 File myFile = new File( "SupplierPurchasePayment.pdf");
     Desktop.getDesktop().open(myFile);
	 
		}catch(Exception ee){
			System.out.println(ee);
		}
	}
	
	
	if(e.getSource()==FinalCustomerPayment.viewPDF){
		try{
	 PdfWriter writer=PdfWriter.getInstance(document, new FileOutputStream("CustomerPayment.pdf"));
	 document.open();
	 document.add(new Paragraph("SUPPLIER PURCHASE PAYMENT"));
	 PdfPTable table=new PdfPTable(2);
	 table.setWidthPercentage(100);
	 table.setSpacingAfter(11f);
	 table.setSpacingBefore(11f);
	 float[] colWidth={1f,1.5f};//,2f,3f,2f,2f,2f,4f,2f,2f,2f,5f,2f,2f,2f,2f,2f,2f,2f};
	 //table.SetTotalWidth(PageSize.A4.Rotate().Width - 25);
	 table.setWidths(colWidth);
	
	/* {"ID","date","stockname","availqty","sellprice","qty",
	 * "discount_per","discount_amount","tax_desc","tax_percent","tax_amount","total_amount Balance","payment Done"
	 * ,"customer_id","address","email","contact_person","customer_name","phn"};*/
	 
	 PdfPCell c2=new PdfPCell(new Paragraph("Date"));
	 PdfPCell cc2=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 1)+""));
	 PdfPCell c3=new PdfPCell(new Paragraph("StockName"));
	 PdfPCell cc3=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 2)+""));
	 PdfPCell c4=new PdfPCell(new Paragraph("Avail.Qty"));
	 PdfPCell cc4=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 3)+""));
	 PdfPCell c5=new PdfPCell(new Paragraph("SellingPrice"));
	 PdfPCell cc5=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 4)+""));
	 PdfPCell c6=new PdfPCell(new Paragraph("Qty"));
	 PdfPCell cc6=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 5)+""));
	 PdfPCell c7=new PdfPCell(new Paragraph("Discount%"));
	 PdfPCell cc7=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 6)+""));
	 PdfPCell c8=new PdfPCell(new Paragraph("DiscountAmount"));
	 PdfPCell cc8=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 7)+""));
	 PdfPCell c9=new PdfPCell(new Paragraph("Tax_Desc"));
	 PdfPCell cc9=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 8)+""));
	 PdfPCell c10=new PdfPCell(new Paragraph("Tax%"));
	 PdfPCell cc10=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 9)+""));
	 PdfPCell c11=new PdfPCell(new Paragraph("TaxAmount"));
	 PdfPCell cc11=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 10)+""));
	 PdfPCell c12=new PdfPCell(new Paragraph("TotalAmount"));
	 PdfPCell cc12=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 11)+""));
	 PdfPCell c13=new PdfPCell(new Paragraph("PaymentDone"));
	 PdfPCell cc13=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 12)+""));
	 PdfPCell c18=new PdfPCell(new Paragraph("CustomerName"));
	 PdfPCell cc18=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 17)+""));
	 PdfPCell c19=new PdfPCell(new Paragraph("Phone"));
	 PdfPCell cc19=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 18)+""));
	 PdfPCell c20=new PdfPCell(new Paragraph("RemainingBalance"));
	 PdfPCell cc20=new PdfPCell(new Paragraph(FinalCustomerPayment.model.getValueAt(0, 19)+""));
	
	
	 table.addCell(c2);
	 table.addCell(cc2);
	 table.addCell(c3);
	 table.addCell(cc3);
	 table.addCell(c4);
	 table.addCell(cc4);
	 table.addCell(c5);
	 table.addCell(cc5);
	 table.addCell(c6);
	 table.addCell(cc6);
	 table.addCell(c7);
	 table.addCell(cc7);
	 table.addCell(c8);
	 table.addCell(cc8);
	 table.addCell(c9);
	 table.addCell(cc9);
	 table.addCell(c10);
	 table.addCell(cc10);
	 table.addCell(c11);
	 table.addCell(cc11);
	 table.addCell(c12);
	 table.addCell(cc12);
	 table.addCell(c13);
	 table.addCell(cc13);
	 table.addCell(c18);
	 table.addCell(cc18);
	 table.addCell(c19);
	 table.addCell(cc19);
	 table.addCell(c20);
		table.addCell(cc20);
		
	
	
	 document.add(table);
	 document.close();
	 writer.close();
	 File myFile = new File( "CustomerPayment.pdf");
     Desktop.getDesktop().open(myFile);
	 
		}catch(Exception ee){
			System.out.println(ee);
		}
	}
}
}
