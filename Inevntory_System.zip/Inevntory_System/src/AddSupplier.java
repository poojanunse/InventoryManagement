import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;


public class AddSupplier implements ActionListener{
	static JTextField supplierName1,email1,cp,pp;
	static JTextArea add1;
	static JButton submit,back;
	static JFrame frame;
	static JLabel status;
	public void actionPerformed(ActionEvent ae){
		
		 frame=new JFrame();
		frame.setVisible(true);
		 frame.setLayout(null);
		 frame.getContentPane().setBackground(Color.white);
		 frame.setSize(1500,1500);
		 frame.setTitle("Welcome to Inventory Management System");
		 
		 JLabel supplierName=new  JLabel("Supplier Name");
		 supplierName.setBounds(70,90,90,60);
		 frame.add(supplierName);
		 supplierName1 =new JTextField();
		 supplierName1.setBounds(250,100,90,20);
		 frame.add(supplierName1);
		 
		 JLabel add=new  JLabel("Address");
		 add.setBounds(70,130,150,60);
		 frame.add(add);
		 add1=new JTextArea();
		 add1.setBounds(250,140,250,30);//250,140,90,20
		 Border border = BorderFactory.createLineBorder(Color.BLACK);
		 //add1.setSize(400, 200);
		 add1.setBorder(border);
		 //add1.setBackground(Color.cyan);
		 frame.add(add1);
		 
		 JLabel phn=new  JLabel("Phone Number");
		  phn.setBounds(70,170,120,60);
		  frame.add(phn);
		   pp =new JTextField();
		  pp.setBounds(250,180,100,20);
		  frame.add(pp);
		  
		  JLabel email=new  JLabel("Email");
		  email.setBounds(70,220,90,60);
		  frame.add(email);
		 email1 =new JTextField();
		  email1.setBounds(250,220,90,20);
		  frame.add(email1);
		  
		  
		  JLabel cperson=new  JLabel("Contact Person");
		  cperson.setBounds(70,260,90,60);
		  frame.add(cperson);
		 cp =new JTextField();
		  cp.setBounds(250,260,90,20);
		  frame.add(cp);
		  
		 
		  Database db=new Database();
		  submit=new JButton("SUBMIT");
		  submit.setBounds(200,300,80,30);
		  submit.setBackground(new Color(51,153,225));
			submit.setForeground(Color.white);
		  submit.addActionListener(db);
		  frame.add(submit);
		  
		  
		  back=new JButton("BACK");
			 CLosePage p=new CLosePage();
			  back.setBounds(300,300,80,30);
			  back.setBackground(new Color(51,153,225));
				back.setForeground(Color.white);
			  back.addActionListener(p);
			  frame.add(back);
			  
			  status=new JLabel();
			  status.setBounds(400, 400, 200, 50);
			  frame.add(status);
			  
			  /*String regex = "^(.+)@(.+)$";
			  Pattern pattern = Pattern.compile(regex);
			  Matcher matcher = pattern.matcher(email1.getText());
			    //System.out.println(email +" : "+ matcher.matches());
			  if(matcher.matches()==false){
				  JOptionPane.showMessageDialog(null, "Sample dialog box");
			  }*/
	}
}
