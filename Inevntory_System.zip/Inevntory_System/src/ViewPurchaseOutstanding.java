import java.awt.Choice;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;




public class ViewPurchaseOutstanding extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTextField purchaseDate1,add1,email1,cp,d,da,td1,tp1,ta1,aa,pp,cpr,email3,pp2,supplierName3,supplierId,um1;
	static JTextArea add2;
	static JButton submit,calculate;
	static JButton back;
	static JFrame frame;
	static JLabel purchaseDate,add,phn,email,cperson,discount,discounta,td,tp,ta,apay,note,status;
	public void actionPerformed(ActionEvent e) {
		 Connection con=null;
		 //AddStock asObject=new AddStock();

		 frame=new JFrame();
		frame.setVisible(true);
		frame.getContentPane().setBackground(Color.white);
		 frame.setLayout(null);
		 frame.setSize(1000,1500);
		 frame.setTitle("Welcome to Inventory Management System");
		 
		  purchaseDate=new JLabel("Purchase Date");
		 purchaseDate.setBounds(70,90,90,60);
		 frame.add(purchaseDate);
		 purchaseDate1 =new JTextField();
		 purchaseDate1.setBounds(250,100,90,20);
		 purchaseDate1.setEditable(false);
		 frame.add(purchaseDate1);
		 
		 JLabel add=new JLabel("Stock Name");
		 add.setBounds(70,130,150,60);
		 frame.add(add);
		  add1=new JTextField();
		 add1.setBounds(250,140,90,20);
		 add1.setEditable(false);
		 frame.add(add1);
		 
		  JLabel phn=new JLabel("Unit of Measurement");
		  phn.setBounds(70,170,120,60);
		  frame.add(phn);
		  um1=new JTextField();
		  um1.setBounds(250,180,90,20);
		  um1.setEditable(false);
		  frame.add(um1);
		  
		  JLabel email=new JLabel("Purchasing Price");
		  email.setBounds(70,210,150,60);
		  frame.add(email);
		 email1 =new JTextField();
		  email1.setBounds(250,220,80,20);
		  email1.setEditable(false);
		  frame.add(email1);
		  
		  JLabel cperson=new JLabel("Quantity");
		  cperson.setBounds(70,250,90,60);
		  frame.add(cperson);
		  cp =new JTextField();
		  cp.setBounds(250,260,20,20);
		  cp.setEditable(false);
		  frame.add(cp);
		  
		  JLabel discount=new JLabel("Discount Percentage");
		  discount.setBounds(70,290,150,60);
		  frame.add(discount);
		 d=new JTextField();
		 d.setBounds(250,300,90,20);
		 d.setEditable(false);
		 frame.add(d);
		 
		 
		 
		 JLabel discounta=new JLabel("Discount Amount");
		  discounta.setBounds(70,330,98,60);
		  frame.add(discounta);
		da=new JTextField();
		 da.setBounds(250,340,90,20);
		 da.setEditable(false);
		 frame.add(da);
		 
		 JLabel td=new JLabel("Tax Desc");
		  td.setBounds(70,370,90,60);//70,370,90,60
		  frame.add(td);
		  td1=new JTextField();
		  td1.setText("GST");
		  td1.setEditable(false);
		 td1.setBounds(250,380,90,20);//250,380,90,20
		 frame.add(td1);
		 
		 JLabel tp=new JLabel("Tax Percent");
		  tp.setBounds(70,410,90,60);//70,410,90,60
		  frame.add(tp);
		   tp1=new JTextField();
		 tp1.setBounds(250,420,90,20);
		 tp1.setEditable(false);
		 frame.add(tp1);
		 
		 JLabel ta=new JLabel("Tax Amount");
		  ta.setBounds(70,450,90,60);
		  frame.add(ta);
		  ta1=new JTextField();
		  ta1.setEditable(false);
		 ta1.setBounds(250,460,90,20);
		 frame.add(ta1);
		 
		 JLabel a=new JLabel("Total Amount");
		  a.setBounds(70,490,150,60);
		  frame.add(a);
		  aa=new JTextField();
		 aa.setBounds(250,500,90,20);
		 aa.setEditable(false);
		 frame.add(aa);
		 
		 JLabel pay=new JLabel("Payment");
		  pay.setBounds(70,530,90,60);//70,530,90,60
		  frame.add(pay);
		   pp=new JTextField();
		pp.setBounds(250,540,90,20);//250,540,90,20
		pp.setEditable(false);
		 frame.add(pp);
		 
		 JLabel supplierid=new  JLabel("Supplier Id");
		 supplierid.setBounds(400,100,100,20);
		 frame.add(supplierid);
		 supplierId =new JTextField();
		 supplierId.setBounds(500,100,90,20);
		 supplierId.setEditable(false);
		 frame.add(supplierId);
		 
		 JLabel supplierName2=new  JLabel("Supplier Name");
		 supplierName2.setBounds(400,140,100,20);
		 frame.add(supplierName2);
		 supplierName3 =new JTextField();
		 supplierName3.setBounds(500,140,90,20);
		 supplierName3.setEditable(false);
		 frame.add(supplierName3);
		 
		 JLabel addd=new  JLabel("Address");
		 addd.setBounds(400,180,100,20);
		 frame.add(addd);
		 add2=new JTextArea();
		 add2.setBounds(500,180,100,20);
		 add2.setEditable(false);
		 frame.add(add2);
		 
		 JLabel phn1=new  JLabel("Phone Number");
		  phn1.setBounds(400,200,120,60);
		  frame.add(phn1);
		   pp2 =new JTextField();
		  pp2.setBounds(500,220,90,20);
		  pp2.setEditable(false);
		  frame.add(pp2);
		  
		 JLabel email2=new  JLabel("Email");
		  email2.setBounds(400,240,90,60);
		  frame.add(email2);
		 email3 =new JTextField();
		  email3.setBounds(500,260,90,20);
		  email3.setEditable(false);
		  frame.add(email3);
		  
		  JLabel cperson1=new  JLabel("Remaining Balance");
		  cperson1.setBounds(400,280,90,60);
		  frame.add(cperson1);
		 cpr =new JTextField();
		  cpr.setBounds(500,300,90,20);
		  cpr.setEditable(false);
		  frame.add(cpr);
		  
		  
		  
		 
		 back=new JButton("BACK");
		 CLosePage p=new CLosePage();
		  back.setBounds(350,580,80,30);
		  back.setBackground(new Color(51,153,225));
			back.setForeground(Color.white);
		  back.addActionListener(p);
		  frame.add(back);
		 
		 try{
			 String date = null,sn = null,unit = null,pp = null,qty = null,dp = null,da = null,tdd = null,tpp = null,taa = null,ttla = null,pays = null,sid = null,spname = null,addds = null,phns = null,emaill = null,cprr = null;
			 Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
			 con.setAutoCommit(false);
			 System.out.println("SQLite3 Connection Established ...");
			
		 java.sql.Statement s=con.createStatement();
		 String query="select * from purchasegoods where id="+PurchaseOutstanding.sname.getText();
		 ResultSet r=s.executeQuery(query);
		 while (r.next()) {
			 date=r.getString(2);
			 sn=r.getString(3);
			 unit=r.getString(4);
			 pp=r.getString(5);
			 qty=r.getString(6);
			 dp=r.getString(7);
			 da=r.getString(8);
			 tdd=r.getString(9);
			 tpp=r.getString(10);
			 taa=r.getString(11);
			 ttla=r.getString(12);
			 pays=r.getString(13);
			 sid=r.getString(14);
			 spname=r.getString(15);
			 addds=r.getString(16);
			 phns=r.getString(17);;
			 emaill=r.getString(18);;
			 cprr=r.getString(20);;
			}
		 ViewPurchaseOutstanding.purchaseDate1.setText(date);
		 ViewPurchaseOutstanding.add1.setText(sn);
		 ViewPurchaseOutstanding.um1.setText(unit);
		 ViewPurchaseOutstanding.email1.setText(pp);
		 ViewPurchaseOutstanding.cp.setText(qty);
		 ViewPurchaseOutstanding.d.setText(dp);
		 ViewPurchaseOutstanding.da.setText(da);
		 ViewPurchaseOutstanding.td1.setText(tdd);
		 ViewPurchaseOutstanding.tp1.setText(tpp);
		 ViewPurchaseOutstanding.ta1.setText(taa);
		 ViewPurchaseOutstanding.aa.setText(ttla);
		 ViewPurchaseOutstanding.pp.setText(pays);
		 ViewPurchaseOutstanding.supplierId.setText(sid);
		 ViewPurchaseOutstanding.supplierName3.setText(spname);
		 ViewPurchaseOutstanding.add2.setText(addds);
		 ViewPurchaseOutstanding.pp2.setText(phns);
		 ViewPurchaseOutstanding.email3.setText(emaill);
		 ViewPurchaseOutstanding.cpr.setText(cprr);
		 
		 }catch(Exception ex){
			 System.out.println(ex);
		 }finally{
			 try{
				 con.close();
			 }catch(Exception ex){
				 System.out.println(ex);
			 }
		 }
		
	}
}
