import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Announcements extends JFrame implements ActionListener {
	static JButton viewannb,addannb,back,delbtn;
	static JFrame frame;
	public void actionPerformed(ActionEvent ae){	
		DesignClass.frame.setVisible(false);
		frame=new JFrame();
		frame.setVisible(true);
		frame.getContentPane().setBackground(Color.white);
		frame.setSize(1500,1500);
		frame.setFont(new Font("Dialog", Font.PLAIN, 12));
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setTitle("Announcements");
		
		AddAnnouncements addStock =new AddAnnouncements();
		ViewAnnouncements viewStock=new ViewAnnouncements();
		
		addannb=new JButton("AddAnnouncements");
		addannb.setBounds(20,200,180,30);
		addannb.addActionListener(addStock);
		addannb.setBackground(new Color(51,153,225));
		addannb.setForeground(Color.white);
		frame.add(addannb);
		
		
		viewannb=new JButton("ViewAnnouncements");
		viewannb.setBounds(20,250,180,30);
		viewannb.addActionListener(viewStock);
		viewannb.setBackground(new Color(51,153,225));
		viewannb.setForeground(Color.white);
		frame.add(viewannb);
		
		
		//DeleteAnnouncements ann=new DeleteAnnouncements();
		Database db=new Database();
		delbtn=new JButton("DeleteAnnouncements");
		delbtn.setBounds(20,300,180,30);
		delbtn.addActionListener(viewStock);
		delbtn.setBackground(new Color(51,153,225));
		delbtn.setForeground(Color.white);
		delbtn.addActionListener(db);
		frame.add(delbtn);
		
		CLosePage close=new CLosePage(); 
		back=new JButton("Back");
		back.setBounds(20,350,180,30);
		back.addActionListener(close);
		back.setBackground(new Color(51,153,225));
		back.setForeground(Color.white);
		frame.add(back);
		
		JLabel image=new JLabel(new ImageIcon(this.getClass().getResource("/images/admin.png")));
		image.setBounds(230, 100, 500, 500);
		frame.add(image);
}
}
