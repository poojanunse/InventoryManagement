import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.swing.JOptionPane;




public class CalculateTax implements ActionListener {
	static double pp,da,amount,tax_amount,discount_amount,total_amount;
	public void actionPerformed(ActionEvent ae){
		
		//PurchaseGoods
		if(ae.getSource()==PurchaseGoods.calculate){
			if(PurchaseGoods.add1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Stock Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
				  else if(PurchaseGoods.d.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Discount Percent should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(PurchaseGoods.tp1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Tax% should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  
				  else if(PurchaseGoods.supplierId.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "SupplierID should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else{
			Connection con=null;
		 	try{
		 		 String sname="",add="",phn="",email="",cp="",pprice="";
		 		 Class.forName("org.sqlite.JDBC");
				 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
				 con.setAutoCommit(false);
				 System.out.println("SQLite3 Connection Established ...");
				
		 java.sql.Statement s=con.createStatement();
		
		 String query2="select supplier_name,address,phn,email,contact_person from addsupplier where id="+	PurchaseGoods.supplierId.getText();
		 String query3="select purchase_price from addstock where stock_name='"+PurchaseGoods.add1.getText()+"'";
		 ResultSet rs=s.executeQuery(query3);
			while (rs.next()) {
				  pprice = rs.getString("purchase_price");
				}
			System.out.println(pprice);
			PurchaseGoods.email1.setText(pprice);
		 ResultSet r=s.executeQuery(query2);
		 while (r.next()) {
			  sname = r.getString("supplier_name");
			  add = r.getString("address");
			  phn = r.getString("phn");
			  email = r.getString("email");
			  cp = r.getString("contact_person");
			}
		 System.out.println(sname+add+phn+email+cp);
		 PurchaseGoods.supplierName3.setText(sname);
		 PurchaseGoods.add2.setText(add);
		 PurchaseGoods.pp2.setText(phn);
		 PurchaseGoods.email3.setText(email);
		 PurchaseGoods.cpr.setText(cp);
		 pp=Integer.parseInt(PurchaseGoods.email1.getText());
		 da=Integer.parseInt(PurchaseGoods.d.getText());
		 amount=pp-da;
		 tax_amount=amount/Integer.parseInt(PurchaseGoods.tp1.getText());
		 discount_amount=Integer.parseInt(PurchaseGoods.email1.getText())/Integer.parseInt(PurchaseGoods.d.getText());
	 total_amount=discount_amount+tax_amount;
		
		PurchaseGoods.da.setText(discount_amount+"");
		PurchaseGoods.ta1.setText(tax_amount+"");
		PurchaseGoods.aa.setText(total_amount+"");
		
		
		 	}catch(Exception e){
		 		System.out.println(e);
		 	}finally{
		 		try{
		 			con.close();
		 		}catch(Exception e){
		 			System.out.println(e);
		 		}
		 	}
		}
		}
		
		
		//saletosupplier
		if(ae.getSource()==SaleToSupplier.calculate){
			if(SaleToSupplier.sname.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Stock Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
				 
				  else if(SaleToSupplier.d.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Discount% should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(SaleToSupplier.tp1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Tax% should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  
				 
				  else if(SaleToSupplier.supplierId.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "SupplierID should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else{
			 Connection con=null;
			 	try{
			 		 String pp_="",qty="";
			 		 Class.forName("org.sqlite.JDBC");
					 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
					 con.setAutoCommit(false);
					 System.out.println("SQLite3 Connection Established ...");
					
			 java.sql.Statement statement=con.createStatement();
			 
			 String query="select remaining_stock from addstock where stock_name='"+SaleToSupplier.sname.getText()+"'";
			 ResultSet result_set=statement.executeQuery(query);
			 
			 while (result_set.next()) {
				  qty = result_set.getString("remaining_stock");
				  System.out.println(qty + "\n");
				}
			 if(qty!=null){
			 SaleToSupplier.aqty.setText(qty);
			 }
			 else{
				 query="select quantity from addstock where stock_name='"+SaleToSupplier.sname.getText()+"'";
				 
			 ResultSet result_sett=statement.executeQuery(query); 
			 
			 while (result_sett.next()) {
				  qty = result_sett.getString("quantity");
				  System.out.println(qty + "\n");
				}
			 SaleToSupplier.aqty.setText(qty);
			 }
			 
			 
			 String query2="select purchase_price from addstock where stock_name='"+SaleToSupplier.sname.getText()+"'";
			 ResultSet result_set1=statement.executeQuery(query2);
			 while (result_set1.next()) {
				  pp_ = result_set1.getString("purchase_price");
				  System.out.println(pp_ + "\n");
				}
			 SaleToSupplier.sprice.setText(pp_);
			 
			 pp=Integer.parseInt(SaleToSupplier.sprice.getText());
			 da=Integer.parseInt(SaleToSupplier.d.getText());
			 
			 String sname="",add="",phn="",email="",cp="";
			 String query3="select supplier_name,address,phn,email,contact_person from addsupplier where id="+	SaleToSupplier.supplierId.getText();
			 java.sql.Statement s=con.createStatement();
			 ResultSet r=s.executeQuery(query3);
			 while (r.next()) {
				  sname = r.getString("supplier_name");
				  add = r.getString("address");
				  phn = r.getString("phn");
				  email = r.getString("email");
				  cp = r.getString("contact_person");
				}
			 System.out.println(sname+add+phn+email+cp);
			 SaleToSupplier.supplierName3.setText(sname);
			 SaleToSupplier.add2.setText(add);
			 SaleToSupplier.pp2.setText(phn);
			 SaleToSupplier.email3.setText(email);
			 SaleToSupplier.cpr.setText(cp);
			 	 
			 
			 
			 amount=pp-da;
			 tax_amount=amount/Integer.parseInt(SaleToSupplier.tp1.getText());
			 discount_amount=Integer.parseInt(SaleToSupplier.sprice.getText())/Integer.parseInt(SaleToSupplier.d.getText());
		 total_amount=discount_amount+tax_amount;
			
			SaleToSupplier.da.setText(discount_amount+"");
			SaleToSupplier.ta1.setText(tax_amount+"");
			SaleToSupplier.aa.setText(total_amount+"");
			 	}catch(Exception e){
			 		System.out.println(e);
			 		
			 	}finally{
			 		try{
			 			con.close();
			 		}catch(Exception e){
			 			System.out.println(e);
			 		}
			 	}
			
		}
		}
		
		
		//saletocustomer
		if(ae.getSource()==SaleToCustomer.calculate){
			if(SaleToCustomer.sname.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Stock Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
				  
				  else if(SaleToCustomer.d.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Discount% should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(SaleToCustomer.tp1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Tax% should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  
				  
				  else if(SaleToCustomer.supplierId.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "CustomerID should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else{
			 Connection con=null;
			 	try{
			 		 String pp_="",qty="";
			 		 Class.forName("org.sqlite.JDBC");
					 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
					 con.setAutoCommit(false);
					 System.out.println("SQLite3 Connection Established ...");
					
			 java.sql.Statement statement=con.createStatement();
			 
			 String query="select remaining_stock from addstock where stock_name='"+SaleToCustomer.sname.getText()+"'";
			 ResultSet result_set=statement.executeQuery(query);
			 while (result_set.next()) {
				  qty = result_set.getString("remaining_stock");
				  System.out.println(qty + "\n");
				}
			 if(qty!=null){
				 SaleToCustomer.aqty.setText(qty);
			 }
				 else{
					 query="select quantity from addstock where stock_name='"+SaleToCustomer.sname.getText()+"'";
				 ResultSet result_sett=statement.executeQuery(query);
				 
				 while (result_sett.next()) {
					  qty = result_sett.getString("quantity");
					  System.out.println(qty + "\n");
					}
				 SaleToCustomer.aqty.setText(qty);
				 }
			 String query2="select purchase_price from addstock where stock_name='"+SaleToCustomer.sname.getText()+"'";
			 ResultSet result_set1=statement.executeQuery(query2);
			 while (result_set1.next()) {
				  pp_ = result_set1.getString("purchase_price");
				  System.out.println(pp_ + "\n");
				}
			 SaleToCustomer.sprice.setText(pp_);
			 
			 pp=Integer.parseInt(SaleToCustomer.sprice.getText());
			 da=Integer.parseInt(SaleToCustomer.d.getText());
			 
			 String sname="",add="",phn="",email="",cp="";
			 String query3="select cust_name,address,phn,email,contact_person from addcustomer where id="+	SaleToCustomer.supplierId.getText();
			 java.sql.Statement s=con.createStatement();
			 ResultSet r=s.executeQuery(query3);
			 while (r.next()) {
				  sname = r.getString("cust_name");
				  add = r.getString("address");
				  phn = r.getString("phn");
				  email = r.getString("email");
				  cp = r.getString("contact_person");
				}
			 System.out.println(sname+add+phn+email+cp);
			 SaleToCustomer.supplierName3.setText(sname);
			 SaleToCustomer.add2.setText(add);
			 SaleToCustomer.pp2.setText(phn);
			 SaleToCustomer.email3.setText(email);
			 SaleToCustomer.cpr.setText(cp);
			 	 
			 
			 amount=pp-da;
			 tax_amount=amount/Integer.parseInt(SaleToCustomer.tp1.getText());
			 discount_amount=Integer.parseInt(SaleToCustomer.sprice.getText())/Integer.parseInt(SaleToCustomer.d.getText());
		 total_amount=discount_amount+tax_amount;
			
			SaleToCustomer.da.setText(discount_amount+"");
			SaleToCustomer.ta1.setText(tax_amount+"");
			SaleToCustomer.aa.setText(total_amount+"");
			 	}catch(Exception e){
			 		System.out.println(e);
			 		
			 	}finally{
			 		try{
			 			con.close();
			 		}catch(Exception e){
			 			System.out.println(e);
			 		}
			 	}
			
		}
		}
		
		
		//PurchaseOutstanding
		if(ae.getSource()==PurchaseOutstanding.calculate){
			if(PurchaseOutstanding.sname.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "PurchaseID should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
			else{
			Connection con=null;
		 	try{
		 		 String pp_="",qty="";
		 		 		double total_amount=0,payment_done=0;
		 		 String remaining_pay="";
		 		 Class.forName("org.sqlite.JDBC");
				 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
				 con.setAutoCommit(false);
				 System.out.println("SQLite3 Connection Established ...");
				
		 java.sql.Statement statement=con.createStatement();
		 String query="select purchasing_price,quantity,total_amount,payment,remaining_balance from purchasegoods where id='"+PurchaseOutstanding.sname.getText()+"'";
		 ResultSet result_set1=statement.executeQuery(query);
		 while (result_set1.next()) {
			  pp_ = result_set1.getString("purchasing_price");
			  qty= result_set1.getString("quantity");
			  total_amount=result_set1.getFloat("total_amount");
			  payment_done=result_set1.getFloat("payment");
			  remaining_pay=result_set1.getString("remaining_balance");
			}
		 System.out.println(pp_+qty+total_amount+payment_done+remaining_pay);
		 PurchaseOutstanding.qty.setText(qty);
		 PurchaseOutstanding.pp.setText(pp_);
		 PurchaseOutstanding.tprice.setText(total_amount+"");
		 PurchaseOutstanding.aprice.setText(payment_done+"");
		 PurchaseOutstanding.bal.setText(remaining_pay+"");
		 
		 
		 	}catch(Exception e){
		 		System.out.println(e);
		 		
		 		}finally{
		 			try{
		 				con.close();
		 			}catch(Exception e){
		 				System.out.println(e);
		 				
		 			}
		 		}
		 	
		}
		}
	
		
		
		//SalesOutstandingSupplier
		if(ae.getSource()==SalesOutstandingSupplier.calculate){
			if(SalesOutstandingSupplier.sname.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "SaleToSupplier ID should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
			else{
			Connection con=null;
		 	try{
		 		 String pp_="",qty="";
		 		 		double total_amount=0,payment_done=0;
		 		 String remaining_pay=null;
		 		 Class.forName("org.sqlite.JDBC");
				 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
				 con.setAutoCommit(false);
				 System.out.println("SQLite3 Connection Established ...");
		 java.sql.Statement statement=con.createStatement();
		 String query="select sellprice,qty,total_amount,payment,remaining_balance from saletosupplier where id='"+SalesOutstandingSupplier.sname.getText()+"'";
		 ResultSet result_set1=statement.executeQuery(query);
		 while (result_set1.next()) {
			  pp_ = result_set1.getString("sellprice");
			  qty= result_set1.getString("qty");
			  total_amount=result_set1.getFloat("total_amount");
			  payment_done=result_set1.getFloat("payment");
			  remaining_pay=result_set1.getString("remaining_balance");
			}
		 System.out.println(pp_+qty+total_amount+payment_done+remaining_pay);
		 SalesOutstandingSupplier.qty.setText(qty);
		 SalesOutstandingSupplier.pp.setText(pp_);
		 SalesOutstandingSupplier.tprice.setText(total_amount+"");
		 SalesOutstandingSupplier.aprice.setText(payment_done+"");
		 SalesOutstandingSupplier.bal.setText(remaining_pay+"");
		 
		 
		 	}catch(Exception e){
		 		System.out.println(e);
		 		
		 		}finally{
		 			try{
		 				con.close();
		 			}catch(Exception e){
		 				System.out.println(e);
		 				
		 			}
		 		}
		 	
		}
		}
		
		
	
		//SalesOutstandingCustomer
		if(ae.getSource()==SalesOutstandingCustomer.calculate){
			if(SalesOutstandingCustomer.sname.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "SaleToCustomer ID should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
			else{
			Connection con=null;
		 	try{
		 		 String pp_="",qty="";
		 		 		double total_amount=0,payment_done=0;
		 		 String remaining_pay=null;
		 		 Class.forName("org.sqlite.JDBC");
				 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
				 con.setAutoCommit(false);
				 System.out.println("SQLite3 Connection Established ...");
				
		 java.sql.Statement statement=con.createStatement();
		 String query="select sellprice,qty,total_amount,payment,remaining_balance from saletocustomer where id='"+SalesOutstandingCustomer.sname.getText()+"'";
		 ResultSet result_set1=statement.executeQuery(query);
		 while (result_set1.next()) {
			  pp_ = result_set1.getString("sellprice");
			  qty= result_set1.getString("qty");
			  total_amount=result_set1.getFloat("total_amount");
			  payment_done=result_set1.getFloat("payment");
			  remaining_pay=result_set1.getString("remaining_balance");
			}
		 System.out.println(pp_+qty+total_amount+payment_done+remaining_pay);
		 SalesOutstandingCustomer.qty.setText(qty);
		 SalesOutstandingCustomer.pp.setText(pp_);
		 SalesOutstandingCustomer.tprice.setText(total_amount+"");
		 SalesOutstandingCustomer.aprice.setText(payment_done+"");
		 SalesOutstandingCustomer.bal.setText(remaining_pay+"");
		 
		 
		 	}catch(Exception e){
		 		System.out.println(e);
		 		
		 		}finally{
		 			try{
		 				con.close();
		 			}catch(Exception e){
		 				System.out.println(e);
		 				
		 			}
		 		}
		 		}
		 	
		}
		
	}
}
