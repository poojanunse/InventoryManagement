import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Test implements ActionListener{
	public void actionPerformed(ActionEvent ae){
		
		 System.out.println(AddStock.stockName1.getText());
		  System.out.println(AddStock.um1.getItem(AddStock.um1.getSelectedIndex()));
		  System.out.println(AddStock.qty1.getText());
		  System.out.println(AddStock.pp.getText());
		  System.out.println(AddStock.date1.getText());
	}
}
