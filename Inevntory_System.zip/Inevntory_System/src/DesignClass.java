import java.awt.*;

import javax.swing.*;
import java.awt.event.*;
import java.sql.Date;
import java.util.Calendar;
public class DesignClass extends JFrame{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JFrame frame;
	DesignClass(){
		 frame=new JFrame();
		frame.setLayout(null);
		frame.setVisible(true);
		frame.getContentPane().setBackground(Color.white);
		frame.setTitle("Welcome to Inventory Management System");
		frame.setSize(1500,1500);
		frame.setFont(new Font("Dialog", Font.PLAIN, 22));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		JLabel title=new JLabel("Welcome To Inventory Management System");
		title.setBounds(350,30,750,50);//
		title.setFont(new Font("Italianate", Font.BOLD, 30));
		//title.setForeground(new Color(204,0,102));
		title.setForeground(Color.blue);
		frame.add(title);
		
		JButton stock =new JButton("Stock Details");
		Stock s=new Stock();
		stock.setBounds(30,100,180,30);
		stock.addActionListener(s);
		stock.setBackground(new Color(51,153,225));
		stock.setForeground(Color.white);
		frame.add(stock);
		
		JButton supplier =new JButton("Supplier Details");
		Supplier ss=new Supplier();
		supplier.setBounds(30,150,180,30);
		supplier.addActionListener(ss);
		supplier.setBackground(new Color(51,153,225));
		supplier.setForeground(Color.white);
		frame.add(supplier);
		
		JButton customer =new JButton("Customer Details");
		Customer cc=new Customer();
		customer.setBounds(30,200,180,30);
		customer.setBackground(new Color(51,153,225));
		customer.setForeground(Color.white);
		customer.addActionListener(cc);
		frame.add(customer);
		
		JButton spurchase =new JButton("SupplierPurchaseDetails");
		Purchase pp=new Purchase();
		spurchase.setBounds(30,250,180,30);
		spurchase.setBackground(new Color(51,153,225));
		spurchase.setForeground(Color.white);
		spurchase.addActionListener(pp);
		frame.add(spurchase);
		
		JButton sales=new JButton("Sales");
		Sales sales1=new Sales();
		sales.setBounds(30,300,180,30);
		sales.setBackground(new Color(51,153,225));
		sales.setForeground(Color.white);
		sales.addActionListener(sales1);
		frame.add(sales);
		
		JButton outstandingb=new JButton("Outstanding");
		Outstanding outstanding=new Outstanding();
		outstandingb.setBounds(30,350,180,30);
		outstandingb.addActionListener(outstanding);
		outstandingb.setBackground(new Color(51,153,225));
		outstandingb.setForeground(Color.white);
		frame.add(outstandingb);
		
		JButton paymentb=new JButton("Payment");
		PaymentMenu p=new PaymentMenu();
		paymentb.setBounds(30,400,180,30);
		paymentb.setBackground(new Color(51,153,225));
		paymentb.setForeground(Color.white);
		paymentb.addActionListener(p);
		frame.add(paymentb);
		
		
		JButton adminb=new JButton("Admin Announcements");
		Announcements a=new Announcements();
		adminb.setBounds(30,450,180,30);
		adminb.setBackground(new Color(51,153,225));
		adminb.setForeground(Color.white);
		adminb.addActionListener(a);
		frame.add(adminb);
		
		JButton reportb=new JButton("Report");
		Report r=new Report();
		reportb.setBounds(30,500,180,30);
		reportb.setBackground(new Color(51,153,225));
		reportb.setForeground(Color.white);
		reportb.addActionListener(r);
		frame.add(reportb);
		
		JLabel image=new JLabel(new ImageIcon(this.getClass().getResource("/images/homeimg.jpg")));
		image.setBounds(150, 100, 1200, 500);//230, 100, 500, 500
		frame.add(image);
		
		
		
	}
	}

