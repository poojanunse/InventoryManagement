import java.awt.Choice;
import java.awt.Color;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;


public class SaleToCustomer implements ActionListener {
	static JButton submit,back,calculate;
	static JFrame frame;
	static JLabel status,note;
	static JTextArea add2;
	static JTextField salesDate1,sname,aqty,sprice,qty,d,da,td1,tp1,ta1,aa,pp,supplierName3,email3,pp2,cpr,supplierId;
public void actionPerformed(ActionEvent ae){
	
	frame=new JFrame();
	frame.getContentPane().setBackground(Color.white);
	frame.setVisible(true);
	 frame.setLayout(null);
	 frame.setSize(1500,1500);
	 frame.setTitle("Welcome to Inventory Management System");
	 
	 JLabel purchaseDate=new JLabel("Sales Date");
	 purchaseDate.setBounds(70,90,90,60);
	 frame.add(purchaseDate);
	 Calendar now = Calendar.getInstance();
     int month = now.get(Calendar.MONTH);
     int day = now.get(Calendar.DAY_OF_MONTH);
     int year = now.get(Calendar.YEAR);
     
	 salesDate1 =new JTextField();
	 salesDate1.setBounds(250,100,90,20);
	 //salesDate1.setText("" + (month + 1) + "/" + day + "/" + year);
	 salesDate1.setText("" +year+ "-" +  (month + 1)  + "-" + day);
	 frame.add(salesDate1);
	 
	 JLabel add=new JLabel("Stock Name");
	 add.setBounds(70,130,150,60);
	 frame.add(add);
	  sname=new JTextField();
	  sname.setBounds(250,140,90,20);
	 frame.add(sname);
	 
	 JLabel phn=new JLabel("Available Quantity");
	  phn.setBounds(70,170,120,60);
	  frame.add(phn);
	  aqty=new JTextField();
	  aqty.setBounds(250,180,90,20);
	  aqty.setEditable(false);
	  frame.add(aqty);
	  
	  JLabel email=new JLabel("Selling Price");
	  email.setBounds(70,210,95,60);
	  frame.add(email);
	 sprice =new JTextField();
	 sprice.setBounds(250,220,90,20);
	 sprice.setEditable(false);
	  frame.add(sprice);
	  
	  JLabel cperson=new JLabel("Quantity");
	  cperson.setBounds(70,250,90,60);
	  frame.add(cperson);
	  qty =new JTextField();
	  qty.setBounds(250,260,90,20);
	  frame.add(qty);
	  
	  JLabel discount=new JLabel("Discount Percentage");
	  discount.setBounds(70,290,150,60);
	  frame.add(discount);
	 d=new JTextField();
	 d.setBounds(250,300,90,20);
	 frame.add(d);
	 
	 
	 
	 JLabel discounta=new JLabel("Discount Amount");
	  discounta.setBounds(70,330,98,60);
	  frame.add(discounta);
	  //discount_amount=(total_amount/100)*discount_percent;
	da=new JTextField();
	//PurchaseGoods.da.setText(""+discount_amount);
	 da.setBounds(250,340,90,20);
	 da.setEditable(false);
	 frame.add(da);
	 
	 JLabel td=new JLabel("Tax Description");
	  td.setBounds(70,370,90,60);//70,370,90,60
	  frame.add(td);
	  td1=new JTextField();
	  td1.setText("GST");
	  td1.setEditable(false);
	 td1.setBounds(250,380,90,20);//250,380,90,20
	 frame.add(td1);
	 
	 JLabel tp=new JLabel("Tax Percent");
	  tp.setBounds(70,410,90,60);//70,410,90,60
	  frame.add(tp);
	   tp1=new JTextField();
	 tp1.setBounds(250,420,90,20);
	 //tax_percent=Integer.parseInt(PurchaseGoods.tp1.getText());
	 frame.add(tp1);
	 
	 JLabel ta=new JLabel("Tax Amount");
	  ta.setBounds(70,450,90,60);
	  frame.add(ta);
	  ta1=new JTextField();
	 ta1.setBounds(250,460,90,20);
	 ta1.setEditable(false);
	 //tax_amount=(total_amount/100)*tax_percent;
	 //PurchaseGoods.ta1.setText(""+tax_amount);
	 frame.add(ta1);
	 
	 JLabel a=new JLabel("Total Amount");
	  a.setBounds(70,490,90,60);
	  frame.add(a);
	  aa=new JTextField();
	 // total_amount=total_amount-(total_amount/100)*discount_percent+tax_amount;
	 aa.setBounds(250,500,90,20);
	 aa.setEditable(false);
	// PurchaseGoods.aa.setText(""+total_amount);
	 frame.add(aa);
	 
	 JLabel pay=new JLabel("Payment");
	  pay.setBounds(70,530,90,60);//70,530,90,60
	  frame.add(pay);
	   pp=new JTextField();
	pp.setBounds(250,540,90,20);//250,540,90,20
	 frame.add(pp);
	 JLabel supplierid=new  JLabel("Customer Id");
	 supplierid.setBounds(400,100,100,20);
	 frame.add(supplierid);
	 supplierId =new JTextField();
	 supplierId.setBounds(500,100,90,20);
	 frame.add(supplierId);
	 
	 JLabel supplierName2=new  JLabel("Customer Name");
	 supplierName2.setBounds(400,140,100,20);
	 frame.add(supplierName2);
	 supplierName3 =new JTextField();
	 supplierName3.setBounds(500,140,90,20);
	 supplierName3.setEditable(false);
	 frame.add(supplierName3);
	 
	 JLabel addd=new  JLabel("Address");
	 addd.setBounds(400,180,100,20);
	 frame.add(addd);
	 add2=new JTextArea();
	 add2.setBounds(500,180,300,20);//500,180,100,20
	 Border border = BorderFactory.createLineBorder(Color.BLACK);
	 //add1.setSize(400, 200);
	 add2.setBorder(border);
	 add2.setEditable(false);
	 frame.add(add2);
	 
	 JLabel phn1=new  JLabel("Phone Number");
	  phn1.setBounds(400,200,120,60);
	  frame.add(phn1);
	   pp2 =new JTextField();
	  pp2.setBounds(500,220,90,20);
	  pp2.setEditable(false);
	  frame.add(pp2);
	  
	 JLabel email2=new  JLabel("Email");
	  email2.setBounds(400,240,90,60);
	  frame.add(email2);
	 email3 =new JTextField();
	  email3.setBounds(500,260,90,20);
	  email3.setEditable(false);
	  frame.add(email3);
	  
	  JLabel cperson1=new  JLabel("Contact Person");
	  cperson1.setBounds(400,280,90,60);
	  frame.add(cperson1);
	 cpr =new JTextField();
	  cpr.setBounds(500,300,90,20);
	  cpr.setEditable(false);
	  frame.add(cpr);
	  
	 
	 
	 Database db=new Database();
	  submit=new JButton("SUBMIT");
	 submit.setBounds(100,600,80,20);
	//  submit.setBounds(200,500,80,30);
	 submit.addActionListener(db);
	 submit.setBackground(new Color(51,153,225));
		submit.setForeground(Color.white);
	 frame.add(submit);
	 
	 CLosePage close=new CLosePage(); 
		back=new JButton("Back");
		back.setBounds(300,600,100,30);
		back.addActionListener(close);
		back.setBackground(new Color(51,153,225));
		back.setForeground(Color.white);
		frame.add(back);
		
		CalculateTax cal=new CalculateTax();
		  calculate=new JButton("CALCULATE");
		  calculate.setBounds(280, 650, 150, 30);
		  calculate.addActionListener(cal);
		  calculate.setBackground(new Color(51,153,225));
			calculate.setForeground(Color.white);
		  frame.add(calculate);
		  
		
		status=new JLabel("");
		status.setBounds(150,650,200,30);
		frame.add(status);
		
		note=new JLabel();
		  note.setBounds(450, 650, 450, 20);
		  note.setText("*Note:Calculate and then put quantity & payment amount..");
		  frame.add(note);
	}

}
