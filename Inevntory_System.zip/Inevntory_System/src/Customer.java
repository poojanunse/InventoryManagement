import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Customer extends JFrame implements ActionListener {
	static JButton addstockb,viewstockb,back;
	static JFrame stockFrame;
	public void actionPerformed(ActionEvent ae){
		DesignClass.frame.setVisible(false);
		stockFrame=new JFrame();
		stockFrame.setVisible(true);
		stockFrame.getContentPane().setBackground(Color.white);
		stockFrame.setSize(1500,1500);
		stockFrame.setFont(new Font("Dialog", Font.PLAIN, 12));
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		stockFrame.setLayout(null);
		stockFrame.setTitle("Customer");
		
		AddCustomer addStock =new AddCustomer();
		ViewCustomer viewStock=new ViewCustomer();
		
		addstockb=new JButton("AddCustomer");
		addstockb.setBounds(30,200,150,30);
		addstockb.setBackground(new Color(51,153,225));
		addstockb.setForeground(Color.white);
		addstockb.addActionListener(addStock);
		stockFrame.add(addstockb);
		
		 viewstockb=new JButton("ViewCustomer");
		viewstockb.setBounds(30,250,150,30);
		viewstockb.setBackground(new Color(51,153,225));
		viewstockb.setForeground(Color.white);
		viewstockb.addActionListener(viewStock);
		stockFrame.add(viewstockb);
		
		CLosePage close=new CLosePage(); 
		back=new JButton("Back");
		back.setBounds(30,300,150,30);
		back.setBackground(new Color(51,153,225));
		back.setForeground(Color.white);
		back.addActionListener(close);
		stockFrame.add(back);
		
		JLabel image=new JLabel(new ImageIcon(this.getClass().getResource("/images/customer.jpg")));
		image.setBounds(230, 100, 800, 500);
		stockFrame.add(image);
	}

}
