import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class OrderId implements ActionListener{
	 static JFrame frame;
	 static JTextField date1,pp;
	 static JTextArea pp1;
	 static JButton btnsubmit,back;
	 static JLabel status ;
public void actionPerformed(ActionEvent arg0) {
	frame=new JFrame();
	frame.setVisible(true);
	 frame.setLayout(null);
	 frame.setSize(600,600);
	 frame.getContentPane().setBackground(Color.white);
	 frame.setTitle("Welcome to Inventory Management System");
	 
	 JLabel l3=new JLabel("Enter Order ID");
	  l3.setBounds(70,130,150,60);
	  frame.add(l3);
	   pp =new JTextField();
	  pp.setBounds(250,140,90,20);
	  frame.add(pp);
	 btnsubmit=new JButton("SUBMIT");
	 FinalSupplierPayment db=new FinalSupplierPayment();
	  btnsubmit.setBounds(200,300,80,30);
	  btnsubmit.addActionListener(db);
	  btnsubmit.setBackground(new Color(51,153,225));
		btnsubmit.setForeground(Color.white);
	  frame.add(btnsubmit);
	  
	  back=new JButton("BACK");
		 CLosePage p=new CLosePage();
		  back.setBounds(300,300,80,30);
		  back.addActionListener(p);
		  back.setBackground(new Color(51,153,225));
			back.setForeground(Color.white);
		  frame.add(back);
	
}
}
