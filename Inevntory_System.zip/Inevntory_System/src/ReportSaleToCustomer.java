import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ReportSaleToCustomer implements ActionListener{
	
	static JFrame frame;
	static JButton back;
	public void actionPerformed(ActionEvent ae){
		
		frame=new JFrame();
		frame.setVisible(true);
		 frame.setLayout(new GridLayout(2,0));
		 frame.getContentPane().setBackground(Color.white);
		 frame.setSize(1500,1500);
		 frame.setTitle("Welcome to Inventory Management System");
		 Connection con=null;
		 String[] columnNames = {"ID"," Date","Stock Name", "AvailQty", "Selling Price", "Quantity","Discount Percentage","Discount Amount","Tax Description","Tax Percent","Tax Amount","Total Amount","PaymentDone","Customer_ID","Address","Email","Contact Person","CustomerrName","phoneNo","RemainingBalance"};

		 
		 DefaultTableModel model = new DefaultTableModel();
			model.setColumnIdentifiers(columnNames);
		 JTable table=new JTable();
		 table.setModel(model);		
			table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			table.setFillsViewportHeight(true);
			table.setBackground(Color.white);
			table.getColumnModel().getColumn(1).setPreferredWidth(10);
			table.getColumnModel().getColumn(2).setPreferredWidth(10);
			
			JScrollPane scroll = new JScrollPane(table);
			scroll.setHorizontalScrollBarPolicy(
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);	
			
			
		 try{
			 int i=0;
			 Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
			 con.setAutoCommit(false);
			 System.out.println("SQLite3 Connection Established ...");
			 String query="select * from saletocustomer where remaining_balance>=1";
			 Statement statement=con.createStatement();
			 ResultSet result_set=statement.executeQuery(query);
			//ResultSetMetaData metadata=result_set.getMetaData();
			 String date,um,sname,pp,qty,dp,da,td,tp,ta,ttla,payment,id,sid,sname1,sadd,sphn,semail,scpr;
			
			// JTable jt=new JTable(result_set[i],metadata[i]);  
			 String row[]={"ID"," Date","Stock Name", "AvailQty", "Selling Price", "Quantity","Discount Percentage","Discount Amount","Tax Description","Tax Percent","Tax Amount","Total Amount","PaymentDone","Customer_ID","Address","Email","Contact Person","CustomerrName","phoneNo","RemainingBalance"};

			 
				while(result_set.next())
		        {
					id=result_set.getString(1);
					date=result_set.getString(2);
					 sname = result_set.getString(3);
					um=result_set.getString(4);
					pp=result_set.getString(5);
					qty=result_set.getString(6);
					dp=result_set.getString(7);
					da=result_set.getString(8);
					td=result_set.getString(9);
					tp=result_set.getString(10);
					ta=result_set.getString(11);
					ttla=result_set.getString(12);
					payment=result_set.getString(13);
					sid=result_set.getString(14);
					sname1=result_set.getString(15);
					sadd=result_set.getString(16);
					sphn=result_set.getString(17);
					semail=result_set.getString(18);
					scpr=result_set.getString(19);
					String rembal=result_set.getString(20);
					
					model.addRow(new Object[]{id,date, sname, um, pp,qty,dp,da,td,tp,ta,ttla,payment,sid,sname1,sadd,sphn,semail,scpr,rembal});
					i++;				
		        }
				if(i <1)
				{
					JOptionPane.showMessageDialog(null, "No Record Found","Error",
							JOptionPane.ERROR_MESSAGE);
				}
				if(i ==1)
				{
				System.out.println(i+" Record Found");
				}
				else
				{
					System.out.println(i+" Records Found");
				}
				
			/*while(result_set.next())
			{
				stock=result_set.getString(1);
				unit=result_set.getString(2);
				purchase_price=result_set.getString(3);
				quantity=result_set.getString(4);
				date1=result_set.getString(5);
				String col[][]={{stock},{unit},{purchase_price},{quantity},{date1}};
				 
				
						
			}*/
			
				 frame.add(scroll);
				 JPanel panel = new JPanel();        
				    panel.setLayout(null);
				 back=new JButton("BACK");
				 CLosePage p=new CLosePage();
				  back.setBounds(300,150,200,30);
				  back.addActionListener(p);
				  back.setBackground(new Color(51,153,225));
					back.setForeground(Color.white);
				  panel.add(back);
				  frame.add(panel);
				
		 }catch(Exception e){
			 System.out.println(e);
		 }finally{
			 try{
				 con.close();
			 }catch(Exception ee){
				 System.out.println(ee);
			 }
		 }
	}
}
