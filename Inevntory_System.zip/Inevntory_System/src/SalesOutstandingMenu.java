import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;


public class SalesOutstandingMenu extends JFrame implements ActionListener{
	static JButton viewstockb,addstockb,back;
	static JFrame salesFrame;
	public void actionPerformed(ActionEvent ae){
		 salesFrame=new JFrame();
		salesFrame.setVisible(true);
		salesFrame.getContentPane().setBackground(Color.white);
		salesFrame.setSize(1500,1500);
		salesFrame.setFont(new Font("Dialog", Font.PLAIN, 12));
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		salesFrame.setLayout(null);
		salesFrame.setTitle("Welcome to Inventory Management System");

		SalesOutstandingSupplier addStock =new SalesOutstandingSupplier();
		SalesOutstandingCustomer viewStock=new SalesOutstandingCustomer();
		
		addstockb=new JButton("SaleToSupplier");
		addstockb.setBounds(30,100,150,30);
		addstockb.setBackground(new Color(51,153,225));
		addstockb.setForeground(Color.white);
		addstockb.addActionListener(addStock);
		salesFrame.add(addstockb);
		
		
		 viewstockb=new JButton("SaleToCustomer");
		viewstockb.setBounds(200,100,150,30);
		viewstockb.addActionListener(viewStock);
		viewstockb.setBackground(new Color(51,153,225));
		viewstockb.setForeground(Color.white);
		salesFrame.add(viewstockb);
		
		CLosePage close=new CLosePage(); 
		back=new JButton("Back");
		back.setBounds(100,200,100,30);
		back.setBackground(new Color(51,153,225));
		back.setForeground(Color.white);
		back.addActionListener(close);
		salesFrame.add(back);
		
	}

}
