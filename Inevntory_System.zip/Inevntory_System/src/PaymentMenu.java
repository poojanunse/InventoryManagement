import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class PaymentMenu extends JFrame implements ActionListener {
	static JButton viewstockb,addstockb,back,dispaddstockb,dispviewstockb;
	static JFrame salesFrame;
	static JTextField id,id1,id2;
	static JLabel um,umm,umm2; 
	static JButton um1,um2;
public void actionPerformed(ActionEvent e) {
	DesignClass.frame.setVisible(false);
	salesFrame=new JFrame();
	salesFrame.setVisible(true);
	salesFrame.getContentPane().setBackground(Color.white);
	salesFrame.setSize(1500,1500);
	salesFrame.setFont(new Font("Dialog", Font.PLAIN, 12));

	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	salesFrame.setLayout(null);
	salesFrame.setTitle("PaymentMenu");

	
	SupplierPayment s=new SupplierPayment();
	/*um=new JLabel(" Enter Id");
	 um.setBounds(70,130,200,20);
	 salesFrame.add(um);
	 id=new JTextField();
	 id.setBounds(70,150,50,20);
	 salesFrame.add(id);*/
	 
	 um1=new JButton("SupplierSalesDetails");
	 um1.setBounds(20,200,200,30);
	 um1.addActionListener(s);
	 um1.setBackground(new Color(51,153,225));
		um1.setForeground(Color.white);
	 salesFrame.add(um1);
	 
	 
	 
	 SupplierPaymentPurchase s1=new SupplierPaymentPurchase();
	/* umm=new JLabel(" Enter Id");
	 umm.setBounds(70,230,200,20);
	 salesFrame.add(umm);
	 id1=new JTextField();
	 id1.setBounds(70,250,50,20);
	 salesFrame.add(id1);*/
	 um2=new JButton("SupplierPurchaseDetails");
	 um2.setBounds(20,250,200,30);
	 um2.addActionListener(s1);
	 um2.setBackground(new Color(51,153,225));
		um2.setForeground(Color.white);
	 salesFrame.add(um2);
	
	 CustomerPayment c=new CustomerPayment();
	 /*umm2=new JLabel(" Enter Id");
	 umm2.setBounds(70,340,200,20);
	 salesFrame.add(umm2);
	 id2=new JTextField();
	 id2.setBounds(70,360,50,20);
	 salesFrame.add(id2);*/
	 viewstockb=new JButton("Customer Details");
	viewstockb.setBounds(20,300,200,30);
	viewstockb.addActionListener(c);
	viewstockb.setBackground(new Color(51,153,225));
	viewstockb.setForeground(Color.white);
	salesFrame.add(viewstockb);
	
	
	CLosePage close=new CLosePage(); 
	back=new JButton("Back");
	back.setBounds(20,350,200,30);
	back.addActionListener(close);
	back.setBackground(new Color(51,153,225));
	back.setForeground(Color.white);
	salesFrame.add(back);
	
	JLabel image=new JLabel(new ImageIcon(this.getClass().getResource("/images/payment.png")));
	image.setBounds(230, 100, 800, 500);
	salesFrame.add(image);
}
}
