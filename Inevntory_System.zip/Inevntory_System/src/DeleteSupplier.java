import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class DeleteSupplier implements ActionListener{

public void actionPerformed(ActionEvent arg0) {
Connection con=null;
	try{
		 Class.forName("org.sqlite.JDBC");
		 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
		 //con.setAutoCommit(false);
		 System.out.println("SQLite3 Connection Established ...");
		 Statement statement=con.createStatement();
		 System.out.println(Database.orderId1.getText());
		 statement.execute("Delete from addsupplier where id="+Database.orderId1.getText());
	}catch(Exception ee){
		System.out.println(ee);
	}finally{
		try{
			con.close();
		}catch(Exception ee){
			System.out.println(ee);
		}
	}
}
}
