import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;



public class Report extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton addstockb,viewstockb,purchase;
	static JButton back;
	static JFrame stockFrame;
	public void actionPerformed(ActionEvent ae){
		DesignClass.frame.setVisible(false);
	 stockFrame=new JFrame();
		stockFrame.setVisible(true);
		stockFrame.getContentPane().setBackground(Color.white);
		stockFrame.setSize(1500,1500);
		stockFrame.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		stockFrame.setLayout(null);
		stockFrame.setTitle("Report");
		
		ReportSaleToSupplier addStock=new ReportSaleToSupplier();
		ReportSaleToCustomer viewStock=new ReportSaleToCustomer();
		ReportPurchase pp=new ReportPurchase();
		
		 addstockb=new JButton("SaleToSupplier");
		addstockb.setBounds(20,200,200,30);
		addstockb.setBackground(new Color(51,153,225));
		addstockb.setForeground(Color.white);
		addstockb.addActionListener(addStock);
		stockFrame.add(addstockb);
		
		 viewstockb=new JButton("SaleToCustomer");	
		viewstockb.setBounds(20,250,200,30);
		viewstockb.setBackground(new Color(51,153,225));
		viewstockb.setForeground(Color.white);
			viewstockb.addActionListener(viewStock);
		stockFrame.add(viewstockb);
		
		purchase=new JButton("PurchaseFromSupplier");
		purchase.setBounds(20,300,200,30);
		purchase.setBackground(new Color(51,153,225));
		purchase.setForeground(Color.white);
		purchase.addActionListener(pp);
		stockFrame.add(purchase);
		
		CLosePage close=new CLosePage(); 
		back=new JButton("Back");
		back.setBounds(20,350,200,30);
		back.setBackground(new Color(51,153,225));
		back.setForeground(Color.white);
		back.addActionListener(close);
		stockFrame.add(back);
		
		JLabel image=new JLabel(new ImageIcon(this.getClass().getResource("/images/reports.jpg")));
		image.setBounds(230, 100, 800, 500);
		stockFrame.add(image);
	}
}
