import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.Statement;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;



public class Database implements ActionListener{
	static JFrame frame;
	static JTextField orderId1;
	static JLabel orderLabel;
	static JButton submit;
	
	 public void actionPerformed(ActionEvent ae){
		 Connection con=null;
		 //AddStock asObject=new AddStock();
		 
		 try{
			 Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
			 // con.setAutoCommit(false);
			 System.out.println("SQLite3 Connection Established ...");
		
		 
		 //addStock
		 if(ae.getSource()==AddStock.btnsubmit){
			 if(AddStock.stockName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Stock Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
				  else if(AddStock.qty1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Quantity should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(AddStock.pp.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Purchasing Price should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else{
		  String stockName1=AddStock.stockName1.getText();
		  String um1=AddStock.um1.getItem(AddStock.um1.getSelectedIndex());
		  String pp=AddStock.pp.getText();
		  String qty1=AddStock.qty1.getText();
		  //String date1=AddStock.date1.getText();
		 
		  //String query="insert into addstock values('"+stockName1+"',"+"'"+um1+"',"+pp+","+qty1+",'"+AddStock.date1.getText()+"')";
		  String query="insert into addstock(stock_name,unit,purchase_price,quantity,date_,remaining_stock)values('"+stockName1+"',"+"'"+um1+"',"+pp+","+qty1+",'"+AddStock.date1.getText()+"',"+qty1+")";
		  //String query ="insert into addstock(stock_name,unit,purchase_price,quantity,date_,remaining_stock)values('grains','KG',500,100,'2017-6-6',100)";
		 Statement statement=con.createStatement();
		 int value=statement.executeUpdate(query);
		 
		 if(value==1){
			 AddStock.status.setText("Record Inserted");
		 }
		 else{
			 AddStock.status.setText("Try Again");
		 }
		 System.out.println(value);
		}
		 }
		 
		 
		 //addCustomer
		 if(ae.getSource()==AddCustomer.submit){
			 String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
	           java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
	           java.util.regex.Matcher m = p.matcher(AddCustomer.email1.getText());
			 if(AddCustomer.supplierName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Customer Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
				  else if(AddCustomer.add1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Address should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(AddCustomer.pp.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Phone Number should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(AddCustomer.cp.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "ContactPerson should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(AddCustomer.email1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Email should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(m.matches()==false){
		        	   JOptionPane.showMessageDialog(null, "EmailAddress not valid", "Alert", JOptionPane.ERROR_MESSAGE); 
		           }
				  else{
			String custName1=AddCustomer.supplierName1.getText(); 
			String pp=AddCustomer.pp.getText();
			String email1=AddCustomer.email1.getText();
			String cp=AddCustomer.cp.getText();
			String add1=AddCustomer.add1.getText();
			
			//String query="insert into addcustomer values('"+custName1+"',"+"'"+add1+"',"+pp+",'"+email1+"',"+"'"+cp+"')";
			String query="insert into addcustomer(cust_name,address,phn,email,contact_person)values('"+custName1+"',"+"'"+add1+"',"+pp+",'"+email1+"','"+cp+"')";
			 Statement statement=con.createStatement();
			 int value=statement.executeUpdate(query);
			
			 if(value==1){
				 AddCustomer.status.setText("Record Inserted");
			 }
			 else{
				 AddCustomer.status.setText("Try Again");
			 }
			 System.out.println(value);
		 }
		 }
		 
		 
		 //addSupplier
		 if(ae.getSource()==AddSupplier.submit){
			
		           String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
		           java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
		           java.util.regex.Matcher m = p.matcher(AddSupplier.email1.getText());
		          
		    
		           if(AddSupplier.supplierName1.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Supplier Name should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
		           }
				  else if(AddSupplier.add1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Address should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(AddSupplier.pp.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Phone Number should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(AddSupplier.email1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Email should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(AddSupplier.cp.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "ContactPerson should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  else if(m.matches()==false){
		        	   JOptionPane.showMessageDialog(null, "EmailAddress not valid", "Alert", JOptionPane.ERROR_MESSAGE); 
		           }
			  else{
			 String supplierName1=AddSupplier.supplierName1.getText(); 
				String pp=AddSupplier.pp.getText();
				String email1=AddSupplier.email1.getText();
				String cp=AddSupplier.cp.getText();
				String add1=AddSupplier.add1.getText(); 
				System.out.println(pp);
				//String query="insert into addsupplier values('"+supplierName1+"',"+"'"+add1+"',"+pp+",'"+email1+"',"+"'"+cp+"')";
				String query="insert into addsupplier(supplier_name,address,phn,email,contact_person)values('"+supplierName1+"',"+"'"+add1+"',"+pp+",'"+email1+"','"+cp+"')";
				 Statement statement=con.createStatement();
				 int value=statement.executeUpdate(query);
				 
				 if(value==1){
					 AddSupplier.status.setText("Record Inserted");
				 }
				 else{
					 AddSupplier.status.setText("Try Again");
				 }
				 System.out.println(value);
			  }
		 }
		 
		 
		 //PurchaseGoods
		 if(ae.getSource()==PurchaseGoods.submit){
			 
			 String date1=PurchaseGoods.purchaseDate1.getText();
			 String add1=PurchaseGoods.add1.getText();
			 String um1=PurchaseGoods.um1.getItem(PurchaseGoods.um1.getSelectedIndex());
			 int purchasing_price=Integer.parseInt(PurchaseGoods.email1.getText());
			 int qty=Integer.parseInt(PurchaseGoods.cp.getText());
			 int discount_percent=Integer.parseInt(PurchaseGoods.d.getText());
			 String tax_desc=PurchaseGoods.td1.getText();
			 int tax_percent=Integer.parseInt(PurchaseGoods.tp1.getText());
			 double payment=Double.parseDouble(PurchaseGoods.pp.getText());
			// String discount_amount,tax_amount,total_amount;
			 int id=Integer.parseInt(PurchaseGoods.supplierId.getText());
			 String sname=PurchaseGoods.supplierName3.getText();
			 String add2=PurchaseGoods.add2.getText();
			 int pp2=Integer.parseInt(PurchaseGoods.pp2.getText());
			 String email3=PurchaseGoods.email3.getText();
			 String cpr=PurchaseGoods.cpr.getText();
			double total_amount = 0,tax_amount,discount_amount;
			 discount_amount=Double.parseDouble(PurchaseGoods.da.getText());
			tax_amount=Double.parseDouble(PurchaseGoods.ta1.getText());
			 total_amount=Double.parseDouble(PurchaseGoods.aa.getText());
			 double bal=total_amount-payment;
			 System.out.println(date1+add1+um1+purchasing_price+qty+discount_amount+tax_desc+tax_percent+payment+id+sname+add2+pp2+email3+cpr+total_amount+tax_amount+bal);
			 Statement statement=con.createStatement();
			  //statement.executeUpdate("insert into purchasegoods values('"+date1+"','"+add1+"','"+um1+"',"+purchasing_price+","+qty+","+discount_percent+","+discount_amount+",'"+tax_desc+"',"+tax_percent+","+tax_amount+","+total_amount+","+payment+")");
			 statement.executeUpdate("insert into purchasegoods (date_,stock_name,unit,purchasing_price,quantity,discount_percent,discount_amount,tax_desc,tax_percent,tax_amount,total_amount,payment,stock_id,supplier_name,address,phn,email,contact_person,remaining_balance) values('"+date1+"','"+add1+"','"+um1+"',"+purchasing_price+","+qty+","+discount_percent+","+discount_amount+",'"+tax_desc+"',"+tax_percent+","+tax_amount+","+total_amount+","+payment+","+id+",'"+sname+"','"+add2+"',"+pp2+",'"+email3+"','"+cpr+"'," +bal +")");
			
			  PurchaseGoods.status.setText("Record Inserted");
			  int rem_qty;
			  String stck_qty=null;
			  
			  ResultSet r=statement.executeQuery("select remaining_stock from addstock where stock_name='"+PurchaseGoods.add1.getText()+"'");
			  while(r.next()){
				  stck_qty=r.getString("remaining_stock");
			  }
			  if(stck_qty.equals("")){
				  ResultSet rr=statement.executeQuery("select quantity from addstock where stock_name='"+PurchaseGoods.add1.getText()+"'");
				  while(rr.next()){
					  stck_qty=r.getString("quantity");
					  rem_qty=Integer.parseInt(stck_qty)-Integer.parseInt(PurchaseGoods.cp.getText());
						System.out.println(rem_qty);
						statement.executeUpdate("update addstock set remaining_stock="+rem_qty +" where stock_name='"+PurchaseGoods.add1.getText()+"'");
				  }
			  }else{
			rem_qty=Integer.parseInt(stck_qty)-Integer.parseInt(PurchaseGoods.cp.getText());
			System.out.println(rem_qty);
			statement.executeUpdate("update addstock set remaining_stock="+rem_qty +" where stock_name='"+PurchaseGoods.add1.getText()+"'");
			  }
		 }
		 
		 
		 
		 
		 
		 
		 //addAnnouncements
		if(ae.getSource()==AddAnnouncements.btnsubmit){
			if(AddAnnouncements.pp.getText().equals("")){
				  JOptionPane.showMessageDialog(null, "Topic should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);
			 }
				  else if(AddAnnouncements.pp1.getText().equals("")){
					  JOptionPane.showMessageDialog(null, "Message should not be empty", "Alert", JOptionPane.ERROR_MESSAGE);  
				  }
				  
				  else{
			 String topic=AddAnnouncements.pp.getText();
			  String msg=AddAnnouncements.pp1.getText();
			  String date1=AddAnnouncements.date1.getText();
			Statement statement=con.createStatement();
			  statement.executeUpdate("insert into addannouncements(date_,topic,message) values('"+date1+"','"+topic+"','"+msg+"')");
			  AddAnnouncements.status.setText("Record Inserted");
				  }  
		}
		
		
		//saleToSupplier
		if(ae.getSource()==SaleToSupplier.submit){
		Statement statement=con.createStatement();
		String date=SaleToSupplier.salesDate1.getText();
		String sname=SaleToSupplier.sname.getText();
		int aqty=Integer.parseInt(SaleToSupplier.aqty.getText());
		int sprice=Integer.parseInt(SaleToSupplier.sprice.getText());
		int qty=Integer.parseInt(SaleToSupplier.qty.getText());
		int d=Integer.parseInt(SaleToSupplier.d.getText());
		double da=Double.parseDouble(SaleToSupplier.da.getText());
		String td1=SaleToSupplier.td1.getText();
		int tp1=Integer.parseInt(SaleToSupplier.tp1.getText());
		double ta1=Double.parseDouble(SaleToSupplier.ta1.getText());
		double aa=Double.parseDouble(SaleToSupplier.aa.getText());
		double pp=Double.parseDouble(SaleToSupplier.pp.getText());
		 int id=Integer.parseInt(SaleToSupplier.supplierId.getText());
		 String sname1=SaleToSupplier.supplierName3.getText();
		 String add2=SaleToSupplier.add2.getText();
		 int pp2=Integer.parseInt(SaleToSupplier.pp2.getText());
		 String email3=SaleToSupplier.email3.getText();
		 String cpr=SaleToSupplier.cpr.getText();
		 double bal=aa-pp;
		System.out.println(date+sname+aqty+sprice+qty+d+da+td1+tp1+ta1+aa+pp+id+sname1+add2+pp2+email3+cpr);
		//String query="insert into saletosupplier values('"+date+"','"+sname+"',"+aqty+","+sprice+","+qty+","+d+","+da+",'"+td1+"',"+tp1+","+ta1+","+aa+","+pp+")";
		String query="insert into saletosupplier(date,stockname,availqty,sellprice,qty,discount_per,discount_amount,tax_desc,tax_percent,tax_amount,total_amount,payment,supplier_id,address,phn,email,contact_person,supplier_name,remaining_balance) values('"+date+"','"+sname+"',"+aqty+","+sprice+","+qty+","+d+","+da+",'"+td1+"',"+tp1+","+ta1+","+aa+","+pp+","+id+",'"+add2+"',"+pp2+",'"+email3+"','"+cpr+"','"+sname1+"',"+bal+")";
		//String query="insert into saletosupplier(date,stockname,availqty,sellprice,qty,discount_per,discount_amount,tax_desc,tax_percent,tax_amount,total_amount,payment,supplier_id,address,phn,email,contact_person,supplier_name) values('2017-06-08','a',7000,200,2,10,10,2,2,2,2,2,1,'sad',23,'wrr',213,'df')+);
		 statement.executeUpdate(query);
		 SaleToSupplier.status.setText("Record Inserted");
		
		 /*int aqty1,qty1,stockqty;
		 aqty1=Integer.parseInt(SaleToSupplier.aqty.getText());
		 qty1=Integer.parseInt(SaleToSupplier.qty.getText());
		 stockqty=aqty1-qty1;
		String query1="update addstock set quantity="+stockqty;
		Statement statement2=con.createStatement();
		statement2.executeUpdate(query1);
		*/
		
		int rem_qty;
		  String stck_qty=null;
		  
		  ResultSet r=statement.executeQuery("select remaining_stock from addstock where stock_name='"+SaleToSupplier.sname.getText()+"'");
		  while(r.next()){
			  stck_qty=r.getString("remaining_stock");
		  }
		rem_qty=Integer.parseInt(stck_qty)-Integer.parseInt(SaleToSupplier.qty.getText());
		System.out.println(rem_qty);
		statement.executeUpdate("update addstock set remaining_stock="+rem_qty +" where stock_name='"+SaleToSupplier.sname.getText()+"'");
		}
		 
		
		
		

		//saleToCustomer
		if(ae.getSource()==SaleToCustomer.submit){
			Statement statement=con.createStatement();
			double ta1=Double.parseDouble(SaleToCustomer.ta1.getText());
			double aa=Double.parseDouble(SaleToCustomer.aa.getText());
			double pp=Double.parseDouble(SaleToCustomer.pp.getText());
			String date=SaleToCustomer.salesDate1.getText();
			String sname=SaleToCustomer.sname.getText();
			int aqty=Integer.parseInt(SaleToCustomer.aqty.getText());
			int sprice=Integer.parseInt(SaleToCustomer.sprice.getText());
			int qty=Integer.parseInt(SaleToCustomer.qty.getText());
			int d=Integer.parseInt(SaleToCustomer.d.getText());
			double da=Double.parseDouble(SaleToCustomer.da.getText());
			String td1=SaleToCustomer.td1.getText();
			int tp1=Integer.parseInt(SaleToCustomer.tp1.getText());
			int id=Integer.parseInt(SaleToCustomer.supplierId.getText());
			 String sname1=SaleToCustomer.supplierName3.getText();
			 String add2=SaleToCustomer.add2.getText();
			 int pp2=Integer.parseInt(SaleToCustomer.pp2.getText());
			 String email3=SaleToCustomer.email3.getText();
			 String cpr=SaleToCustomer.cpr.getText();
			 double bal=aa-pp;
				System.out.println(date+sname+aqty+sprice+qty+d+da+td1+tp1+ta1+aa+pp+id+sname1+add2+pp2+email3+cpr);
				//String query="insert into saletosupplier values('"+date+"','"+sname+"',"+aqty+","+sprice+","+qty+","+d+","+da+",'"+td1+"',"+tp1+","+ta1+","+aa+","+pp+")";
				String query="insert into saletocustomer(date,stockname,availqty,sellprice,qty,discount_per,discount_amount,tax_desc,tax_percent,tax_amount,total_amount,payment,customer_id,address,email,contact_person,customer_name,phn,remaining_balance) values('"+date+"','"+sname+"',"+aqty+","+sprice+","+qty+","+d+","+da+",'"+td1+"',"+tp1+","+ta1+","+aa+","+pp+","+id+",'"+add2+"','"+email3+"','"+cpr+"','"+sname1+"',"+pp2+","+bal+")";
				//String query="insert into saletosupplier(date,stockname,availqty,sellprice,qty,discount_per,discount_amount,tax_desc,tax_percent,tax_amount,total_amount,payment,supplier_id,address,phn,email,contact_person,supplier_name) values('2017-06-08','a',7000,200,2,10,10,2,2,2,2,2,1,'sad',23,'wrr',213,'df')+);
				 statement.executeUpdate(query);
			 SaleToCustomer.status.setText("Record Inserted");
			 /*int aqty1,qty1,stockqty;
			 aqty1=Integer.parseInt(SaleToCustomer.aqty.getText());
			 qty1=Integer.parseInt(SaleToCustomer.qty.getText());
			 stockqty=aqty1-qty1;
			String query1="update addstock set quantity="+stockqty;
			Statement statement2=con.createStatement();
			statement2.executeUpdate(query1);*/
			int rem_qty;
			  String stck_qty=null;
			  
			  ResultSet r=statement.executeQuery("select remaining_stock from addstock where stock_name='"+SaleToCustomer.sname.getText()+"'");
			  while(r.next()){
				  stck_qty=r.getString("remaining_stock");
			  }
			rem_qty=Integer.parseInt(stck_qty)-Integer.parseInt(SaleToCustomer.qty.getText());
			System.out.println(rem_qty);
			statement.executeUpdate("update addstock set remaining_stock="+rem_qty +" where stock_name='"+SaleToCustomer.sname.getText()+"'");
			}
		
		
		//PurchaseOutstanding
		if(ae.getSource()==PurchaseOutstanding.submit){
			double remaining=0,amt;
			String payment=PurchaseOutstanding.pay.getText();
			remaining=Double.parseDouble(PurchaseOutstanding.bal.getText());
			amt=remaining-Integer.parseInt(payment);
			String query1="update purchasegoods set remaining_balance="+amt+" where id="+PurchaseOutstanding.sname.getText() ;
			Statement statement1=con.createStatement();
			 statement1.executeUpdate(query1);
			 PurchaseOutstanding.status.setText("Submited Successfully ..");
		}
		
		
		//SalesOutstandingSupplier
		if(ae.getSource()==SalesOutstandingSupplier.submit){
			double remaining=0,amt;
			String payment=SalesOutstandingSupplier.pay.getText();
			remaining=Double.parseDouble(SalesOutstandingSupplier.bal.getText());
			amt=remaining-Integer.parseInt(payment);
			String query1="update saletosupplier set remaining_balance="+amt+" where id="+SalesOutstandingSupplier.sname.getText();
			Statement statement1=con.createStatement();
			 statement1.executeUpdate(query1);
			 SalesOutstandingSupplier.status.setText("Submited Successfully ..");
		}
		
		
		//SalesOutstandingCustomer
		if(ae.getSource()==SalesOutstandingCustomer.submit){
			double remaining=0,amt;
			String payment=SalesOutstandingCustomer.pay.getText();
			remaining=Double.parseDouble(SalesOutstandingCustomer.bal.getText());
			amt=remaining-Integer.parseInt(payment);
			String query1="update saletocustomer set remaining_balance="+amt+" where id="+SalesOutstandingCustomer.sname.getText();;
			Statement statement1=con.createStatement();
			 statement1.executeUpdate(query1);
			 SalesOutstandingCustomer.status.setText("Submited Successfully ..");
		}
		
		
		
		//viewStock
		if(ae.getSource()==ViewStock.delStock){
			frame=new JFrame();
			frame.setVisible(true);
			 frame.setLayout(null);
			 frame.getContentPane().setBackground(Color.white);
			 frame.setSize(300,300);
			 frame.setTitle("DeleteStock");
			 
			 
			 orderLabel=new JLabel("Enter Stock Order Id");
			 orderLabel.setBounds(30,30,150,30);
			 frame.add(orderLabel);
			 orderId1=new JTextField();
			 orderId1.setBounds(180,40,80,20);
			 frame.add(orderId1);
			 
			 
			 DeleteStock d=new DeleteStock();
			 submit=new JButton("SUBMIT");
			 submit.setBounds(50,70,80,30);
			  submit.setBackground(new Color(51,153,225));
			  submit.setForeground(Color.white);
			  submit.addActionListener(d);
			 frame.add(submit);
			 
			 
		}
		
		
		
		//viewSupplier
		if(ae.getSource()==ViewSupplier.delStock){
			frame=new JFrame();
			frame.setVisible(true);
			 frame.setLayout(null);
			 frame.getContentPane().setBackground(Color.white);
			 frame.setSize(300,300);
			 frame.setTitle("DeleteSupplier");
			 
			 orderLabel=new JLabel("Enter Supplier Order Id");
			 orderLabel.setBounds(30,30,150,30);
			 frame.add(orderLabel);
			 orderId1=new JTextField();
			 orderId1.setBounds(180,40,80,20);
			 frame.add(orderId1);
			 
			 
			 DeleteSupplier d=new DeleteSupplier();
			 submit=new JButton("SUBMIT");
			 submit.setBounds(50,70,80,30);
			  submit.setBackground(new Color(51,153,225));
			  submit.setForeground(Color.white);
			  submit.addActionListener(d);
			 frame.add(submit);
		}
		
		
		
		//viewCustomer
		if(ae.getSource()==ViewCustomer.delStock){
			frame=new JFrame();
			frame.setVisible(true);
			 frame.setLayout(null);
			 frame.getContentPane().setBackground(Color.white);
			 frame.setSize(300,300);
			 frame.setTitle("DeleteCustomer");
			 
			 orderLabel=new JLabel("Enter Customer Order Id");
			 orderLabel.setBounds(30,30,150,30);
			 frame.add(orderLabel);
			 orderId1=new JTextField();
			 orderId1.setBounds(180,40,80,20);
			 frame.add(orderId1);
			 
			 
			 DeleteCustomer d=new DeleteCustomer();
			 submit=new JButton("SUBMIT");
			 submit.setBounds(50,70,80,30);
			  submit.setBackground(new Color(51,153,225));
			  submit.setForeground(Color.white);
			  submit.addActionListener(d);
			 frame.add(submit);
		}
		
		
		
		//Announcements
		if(ae.getSource()==Announcements.delbtn){
			frame=new JFrame();
			frame.setVisible(true);
			 frame.setLayout(null);
			 frame.getContentPane().setBackground(Color.white);
			 frame.setSize(300,300);
			 frame.setTitle("DeleteAnnouncements");
			 
			 orderLabel=new JLabel("Enter Order Id");
			 orderLabel.setBounds(30,30,150,30);
			 frame.add(orderLabel);
			 orderId1=new JTextField();
			 orderId1.setBounds(180,40,80,20);
			 frame.add(orderId1);
			 
			 
			 DeleteAnnouncements d=new DeleteAnnouncements();
			 submit=new JButton("SUBMIT");
			 submit.setBounds(50,70,80,30);
			  submit.setBackground(new Color(51,153,225));
			  submit.setForeground(Color.white);
			  submit.addActionListener(d);
			 frame.add(submit);
		}
		
		
		
		 }catch(Exception e){
			 System.out.println(e);
		 }
		 
		 finally{
			 try{
		 con.close();
			 }catch(Exception ex){
				 System.out.println(ex);
				 	 
			 }
		 }
		 
	
		 
	}
}
