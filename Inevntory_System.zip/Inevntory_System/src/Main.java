
public class Main {
	public static void main(String ars[]){
	DesignClass object=new DesignClass();
	}
}
