import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Outstanding extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JButton salesb,purchaseb,back;
	static JFrame salesFrame;
	public void actionPerformed(ActionEvent ae){
		DesignClass.frame.setVisible(false);
		 salesFrame=new JFrame();
		salesFrame.setVisible(true);
		salesFrame.setSize(1500,1500);
		salesFrame.getContentPane().setBackground(Color.white);
		salesFrame.setFont(new Font("Dialog", Font.PLAIN, 12));
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		salesFrame.setLayout(null);
		salesFrame.setTitle("Outstanding");

		PurchaseOutstanding addStock =new PurchaseOutstanding();
		SalesOutstandingMenu viewStock=new SalesOutstandingMenu();
		
		salesb=new JButton("PurchaseOutstanding");
		salesb.setBounds(30,200,180,30);
		salesb.addActionListener(addStock);
		salesb.setBackground(new Color(51,153,225));
		salesb.setForeground(Color.white);
		salesFrame.add(salesb);
		
		
		purchaseb=new JButton("SalesOutstanding");
		purchaseb.setBounds(30,250,180,30);
		purchaseb.addActionListener(viewStock);
		purchaseb.setBackground(new Color(51,153,225));
		purchaseb.setForeground(Color.white);
		salesFrame.add(purchaseb);
		
		CLosePage close=new CLosePage(); 
		back=new JButton("Back");
		back.setBounds(30,300,180,30);
		back.addActionListener(close);
		back.setBackground(new Color(51,153,225));
		back.setForeground(Color.white);
		salesFrame.add(back);
		
		JLabel image=new JLabel(new ImageIcon(this.getClass().getResource("/images/outstanding.png")));
		image.setBounds(230, 100, 800, 500);
		salesFrame.add(image);
	}
}
