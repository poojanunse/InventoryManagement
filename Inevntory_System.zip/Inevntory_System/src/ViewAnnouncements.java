import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class ViewAnnouncements implements ActionListener {
	static JButton back;
	static JFrame frame;
	public void actionPerformed(ActionEvent ae){
		
		frame=new JFrame();
		frame.getContentPane().setBackground(Color.white);
		frame.setVisible(true);
		 //frame.setLayout(new FlowLayout());
		frame.setLayout(new GridLayout(2,0));
		 frame.setSize(1500,1500);
		 frame.setTitle("Welcome to Inventory Management System");
		 Connection con=null;
		 String[] columnNames = {"ID","Date","Topic", "Message"};

		 
		 DefaultTableModel model = new DefaultTableModel();
			model.setColumnIdentifiers(columnNames);
		 JTable table=new JTable();
		 table.setModel(model);		
			table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
			table.setFillsViewportHeight(true);
			table.setBackground(Color.white);
			table.getColumnModel().getColumn(1).setPreferredWidth(10);
			table.getColumnModel().getColumn(2).setPreferredWidth(10);
			
			JScrollPane scroll = new JScrollPane(table);
			scroll.setHorizontalScrollBarPolicy(
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setVerticalScrollBarPolicy(
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);		
						
			
		 try{
			 int i=0;
			 Class.forName("org.sqlite.JDBC");
			 con=DriverManager.getConnection("jdbc:sqlite:sqlite/InventoryManagement.db");
			 con.setAutoCommit(false);
			 System.out.println("SQLite3 Connection Established ...");
			
			 String query="select * from addannouncements";
			 Statement statement=con.createStatement();
			 ResultSet result_set=statement.executeQuery(query);
			//ResultSetMetaData metadata=result_set.getMetaData();
			 String stock="",unit="",purchase_price="",quantity="";
			
			// JTable jt=new JTable(result_set[i],metadata[i]);  
			 String row[]={"Date","Topic","Message"};
			 
				while(result_set.next())
		        {
					stock=result_set.getString(1);
					unit=result_set.getString(2);
					purchase_price=result_set.getString(3);	
					String msg=result_set.getString(4);
					model.addRow(new Object[]{stock,unit,purchase_price,msg});
					i++;				
		        }
				if(i <1)
				{
					JOptionPane.showMessageDialog(null, "No Record Found","Error",
							JOptionPane.ERROR_MESSAGE);
				}
				if(i ==1)
				{
				System.out.println(i+" Record Found");
				}
				else
				{
					System.out.println(i+" Records Found");
				}
				
			/*while(result_set.next())
			{
				stock=result_set.getString(1);
				unit=result_set.getString(2);
				purchase_price=result_set.getString(3);
				quantity=result_set.getString(4);
				date1=result_set.getString(5);
				String col[][]={{stock},{unit},{purchase_price},{quantity},{date1}};
				 
				
						
			}*/
			
				 frame.add(scroll);
				 JPanel panel = new JPanel();        
				    panel.setLayout(null);
				    //JButton component= new JButton("Component");
				   
				 back=new JButton("BACK");
				 CLosePage p=new CLosePage();
				  back.setBounds(500,100,80,30);
				// back.setPreferredSize(new Dimension(10, 60));
				  back.setBackground(new Color(51,153,225));
				back.setForeground(Color.white);
				  back.addActionListener(p);
				  panel.add(back );
				  frame.add(panel);
				 // frame.add(back);
		 }catch(Exception e){
			 System.out.println(e);
		 }finally{
			 try{
				 con.close();
			 }catch(Exception ee){
				 System.out.println(ee);
			 }
		 }
	}
}


