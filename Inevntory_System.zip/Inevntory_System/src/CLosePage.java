import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;




public class CLosePage implements ActionListener {
	public void actionPerformed(ActionEvent ae){
	
		if(ae.getSource()==Stock.back){
			Stock.stockFrame.dispose();
			new DesignClass();
		}
		if(ae.getSource()==Customer.back){
			Customer.stockFrame.dispose();
			new DesignClass();
		}
		if(ae.getSource()==Supplier.back){
			Supplier.stockFrame.dispose();
			new DesignClass();
		}
		if(ae.getSource()==Purchase.back){
			Purchase.stockFrame.dispose();
			new DesignClass();
		}
		if(ae.getSource()==Sales.back){
			Sales.salesFrame.dispose();
			new DesignClass();
		}
		if(ae.getSource()==Outstanding.back){
			Outstanding.salesFrame.dispose();
			new DesignClass();
		}
		if((ae.getSource()==AddStock.back)){
			AddStock.frame.dispose();
			new Stock();
		}
		if((ae.getSource()==AddCustomer.back)){
			AddCustomer.frame.dispose();
			new Customer();
		}
		if((ae.getSource()==AddSupplier.back)){
			AddSupplier.frame.dispose();
			new Supplier();
		}
		if((ae.getSource()==PurchaseGoods.back)){
			PurchaseGoods.frame.dispose();
			new Purchase();
		}
		if((ae.getSource()==SaleToCustomer.back)){
			SaleToCustomer.frame.dispose();
			new Sales();
		}
		if((ae.getSource()==SaleToSupplier.back)){
			SaleToSupplier.frame.dispose();
			new Sales();
		}
		if((ae.getSource()==SalesOutstandingMenu.back)){
			SalesOutstandingMenu.salesFrame.dispose();
			new Outstanding();
		}
		if((ae.getSource()==PurchaseOutstanding.back)){
			PurchaseOutstanding.frame.dispose();
			new Outstanding();
		}
		if((ae.getSource()==Announcements.back)){
			Announcements.frame.dispose();
			new DesignClass();
		}
		if((ae.getSource()==AddAnnouncements.back)){
			AddAnnouncements.frame.dispose();
			new Announcements();
		}
		if((ae.getSource()==ViewAnnouncements.back)){
			ViewAnnouncements.frame.dispose();
			new Announcements();
		}
		if((ae.getSource()==ViewStock.back)){
			ViewStock.frame.dispose();
			new Stock();
		}
		if((ae.getSource()==ViewSupplier.back)){
			ViewSupplier.frame.dispose();
			new Supplier();
		}
		if((ae.getSource()==ViewCustomer.back)){
			ViewCustomer.frame.dispose();
			new Customer();
		}
		if((ae.getSource()==ViewPurchase.back)){
			ViewPurchase.frame.dispose();
			new Purchase();
		}
		if(ae.getSource()==SalesOutstandingSupplier.back){
			SalesOutstandingSupplier.frame.dispose();
			new SalesOutstandingMenu(); 
		}
		if(ae.getSource()==SalesOutstandingCustomer.back){
			SalesOutstandingCustomer.frame.dispose();
			new SalesOutstandingMenu(); 
		}
		if(ae.getSource()==ViewPurchaseOutstanding.back){
			ViewPurchaseOutstanding.frame.dispose();
			new PurchaseOutstanding();
		}
		
		if(ae.getSource()==ViewSalesSuppOutstanding.back){
			ViewSalesSuppOutstanding.frame.dispose();
			new SalesOutstandingSupplier();
		}
		
		if(ae.getSource()==ViewSalesCustOutstanding.back){
			ViewSalesCustOutstanding.frame.dispose();
			new SalesOutstandingCustomer();
		}
		if(ae.getSource()==ViewSale.back){
			ViewSale.frame.dispose();
			new Sales();
		}
		if(ae.getSource()==PaymentMenu.back){
			PaymentMenu.salesFrame.dispose();
			new DesignClass();
		}
		if(ae.getSource()==SupplierPayment.back){
			SupplierPayment.frame.dispose();
			new PaymentMenu();
		}
		if(ae.getSource()==CustomerPayment.back){
			CustomerPayment.frame.dispose();
			new PaymentMenu();
		}
		if(ae.getSource()==SupplierPaymentPurchase.back){
			SupplierPaymentPurchase.frame.dispose();
			new PaymentMenu();
		}
		if(ae.getSource()==OrderId.back){
			OrderId.frame.dispose();
		new PaymentMenu();
	}
		if(ae.getSource()==SupplierPaymentPurchaseOrderId.back){
			SupplierPaymentPurchaseOrderId.frame.dispose();
		new PaymentMenu();
		}
		if(ae.getSource()==CustomerOrderId.back){
			CustomerOrderId.frame.dispose();
			new PaymentMenu();
		}
		if(ae.getSource()==FinalSupplierPayment.back){
			FinalSupplierPayment.frame.dispose();
			OrderId.frame.dispose();
			SupplierPayment.frame.dispose();
			new PaymentMenu();
		}
		if(ae.getSource()==FinalSupplierPurchasePayment.back){
			FinalSupplierPurchasePayment.frame.dispose();
			SupplierPaymentPurchaseOrderId.frame.dispose();
			SupplierPaymentPurchase.frame.dispose();
			new PaymentMenu();
		}
		if(ae.getSource()==FinalCustomerPayment.back){
			FinalCustomerPayment.frame.dispose();
			CustomerOrderId.frame.dispose();
			CustomerPayment.frame.dispose();
			new PaymentMenu();
		}
		if(ae.getSource()==Report.back){
			Report.stockFrame.dispose();
			new DesignClass();
		}
		if(ae.getSource()==CustomerPayment.back){
			CustomerPayment.frame.dispose();
			new PaymentMenu();
		}
		if(ae.getSource()==ReportPurchase.back){
			ReportPurchase.frame.dispose();
			new Report();
		}
		if(ae.getSource()==ReportSaleToCustomer.back){
			ReportSaleToCustomer.frame.dispose();
			new Report();
		}
		if(ae.getSource()==ReportSaleToSupplier.back){
			ReportSaleToSupplier.frame.dispose();
			new Report();
		}
	}
}
