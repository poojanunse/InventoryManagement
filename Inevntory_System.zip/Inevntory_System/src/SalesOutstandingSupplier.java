import java.awt.Color;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class SalesOutstandingSupplier extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTextField sname,qty,pp,tprice,aprice,pay,bal;
	static JButton submit,back,calculate,view1;
	static JFrame frame;
	static JLabel note,status; 
	public void actionPerformed(ActionEvent ae){
		 frame=new JFrame();
		frame.setVisible(true);
		 frame.setLayout(null);
		 frame.setSize(1500,1500);
		 frame.getContentPane().setBackground(Color.white);
		 frame.setTitle("Welcome to Inventory Management System");
		 
		 JLabel purchaseDate=new JLabel("SaleToSupplier ID");
		 purchaseDate.setBounds(70,90,150,60);
		 frame.add(purchaseDate);
		 sname =new JTextField();
		 sname.setBounds(250,100,90,20);
		 frame.add(sname);
		 
		 JLabel add=new JLabel("Stock Quantity");
		 add.setBounds(70,130,150,60);
		 frame.add(add);
		 qty=new JTextField();
		  qty.setBounds(250,140,90,20);
		  qty.setEditable(false);
		 frame.add(qty);
		 
		  JLabel phn=new JLabel("Selling Price");
		  phn.setBounds(70,170,120,60);
		  frame.add(phn);
		  pp=new JTextField();
		  pp.setBounds(250,180,90,20);
		  pp.setEditable(false);
		  frame.add(pp);
		  
		  JLabel email=new JLabel("Total Payment");
		  email.setBounds(70,210,100,60);
		  frame.add(email);
		 tprice =new JTextField();
		 tprice.setBounds(250,220,90,20);
		 tprice.setEditable(false);
		  frame.add(tprice);
		  
		  JLabel cperson=new JLabel("Advance Payment");
		  cperson.setBounds(70,250,100,60);
		  frame.add(cperson);
		  aprice =new JTextField();
		  aprice.setBounds(250,260,90,20);
		 aprice.setEditable(false);
		  frame.add(aprice);
		  
		  JLabel discount=new JLabel("Remaining Balance");
		  discount.setBounds(70,290,150,60);
		  frame.add(discount);
		bal=new JTextField();
		 bal.setBounds(250,300,90,20);
		 bal.setEditable(false);
		 frame.add(bal);
		 
		 
		 
		 JLabel discounta=new JLabel("Payment");
		  discounta.setBounds(70,330,98,60);
		  frame.add(discounta);
		 
		pay=new JTextField();
		
		 pay.setBounds(250,340,90,20);
		 frame.add(pay);
		 
		 	Database db=new Database();
		  submit=new JButton("SUBMIT");
		 submit.setBounds(100,400,80,30);
		 submit.setBackground(new Color(51,153,225));
			submit.setForeground(Color.white);
		  
		 submit.addActionListener(db);
		 frame.add(submit);
		 back=new JButton("BACK");
		 CLosePage p=new CLosePage();
		  back.setBounds(200,400,80,30);
		  back.addActionListener(p);
		  back.setBackground(new Color(51,153,225));
			back.setForeground(Color.white);
		  frame.add(back);
		  CalculateTax cal=new CalculateTax();
		  calculate=new JButton("Search Stock");
		  calculate.setBounds(300, 400, 150, 30);
		  calculate.addActionListener(cal);
		  calculate.setBackground(new Color(51,153,225));
			calculate.setForeground(Color.white);
		  frame.add(calculate);
		  status=new JLabel("");
		  status.setBounds(200,450,300,30);
		  frame.add(status);
		  
		  note=new JLabel("*Note:Search Stock First ...");
		  note.setBounds(200,500,300,30);
		  frame.add(note);
		  
		  ViewSalesSuppOutstanding view=new ViewSalesSuppOutstanding();
		  view1=new JButton("VIEW SALES DEATILS");
			 view1.setBounds(500,400,300,30);
			 view1.addActionListener(view);
			 view1.setBackground(new Color(51,153,225));
				view1.setForeground(Color.white);
			  frame.add(view1);
	}

}
