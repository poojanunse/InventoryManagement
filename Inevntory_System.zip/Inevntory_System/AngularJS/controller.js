var application=angular.module('myapp',['ngRoute']);
application.config(function ($routeProvider){

.when('/'
{template: "Welcome User .."})

.when('/anotherPage'
{template:"Welcome User Again .."})

.other(
{template:"Welcome User .."})
);
})